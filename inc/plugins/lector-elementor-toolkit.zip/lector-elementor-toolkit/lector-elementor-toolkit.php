<?php
/*
 * Plugin Name: Lector Elementor Toolkit
 * Plugin URI: https://themeforest.net/user/codexcoder
 * Description: This plugin is mandatory for the theme lector
 * Author: CodexCoder
 * Author URI: http://codexcoder.com/
 * Version: 1.0.0
 * Text Domain: lector
 */

use \Elementor\Plugin as Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	die( __( "Direct Access is not allowed", 'lector' ) );
}

final class LectorCompanionExtension {

	const VERSION = "1.0.0";
	const MINIMUM_ELEMENTOR_VERSION = "2.0.0";
	const MINIMUM_PHP_VERSION = "5.6";

	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;

	}

	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	public function init() {
		load_plugin_textdomain( 'lector', false, dirname( __FILE__ ) . "/languages" );

		// Check if Elementor installed and activated-----------------
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );

			return;
		}

		// Check for required Elementor version-------------------
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );

			return;
		}

		// Check for required PHP version------------------------------------
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );

			return;
		}


		add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );

		////Register with add action all category style css js and init here -------------------------
		add_action( 'elementor/widgets/widgets_registered', 	[ $this, 'init_widgets' ] );
		add_action( "elementor/elements/categories_registered", [ $this, 'register_new_category' ] );
		add_action( "elementor/frontend/after_enqueue_styles",  [ $this, 'frontend_assets_styles' ] );
		add_action( "elementor/frontend/after_enqueue_scripts", [ $this, 'frontend_assets_scripts' ] );

	}

	//Register all widgets js file  here --------------------------------------
	function frontend_assets_scripts(){ }


	//enqueue all widgets css file here--------------------------------------
	function frontend_assets_styles() {}

	//Register category for plugins---------------------------------
	public function register_new_category( $manager ) {
		$manager->add_category( 'lector', [
			'title' => __( 'Lector Elementor Toolkit', 'lector' ),
			'icon'  => 'fa fa-image'
		] );

	}

	/*Register all widget file here*/
	public function init_widgets() {
		require_once (__DIR__."/widgets/lector-coming-soon.php");
		require_once (__DIR__."/widgets/about-page-video-addon.php");
		require_once (__DIR__."/widgets/counterup-testmonial-addon.php");
		require_once (__DIR__."/widgets/sponsore-section-addon.php");
		require_once (__DIR__."/widgets/newsletter-subscribe-addon.php");
		require_once (__DIR__."/widgets/head-of-ideas-addon.php");
		require_once (__DIR__."/widgets/lector-testimonial-addon.php");
		require_once (__DIR__."/widgets/home-banner.php");
		require_once (__DIR__."/widgets/home-one-services-one.php");
		require_once (__DIR__."/widgets/home-one-client-videos.php");
		require_once (__DIR__."/widgets/home-one-service-solution.php");
		require_once (__DIR__."/widgets/home-one-progress-section.php");
		require_once (__DIR__."/widgets/how-we-work-section.php");
		require_once (__DIR__."/widgets/how-case-study-section.php");
		require_once (__DIR__."/widgets/lector-advisor-section-addon.php");
		require_once (__DIR__."/widgets/latest-blog-addon.php");
		require_once (__DIR__."/widgets/hove-contact-addon.php");
		require_once (__DIR__."/widgets/lector-faq-addon.php");
		require_once (__DIR__."/widgets/advisor-testimonial.php");
		require_once (__DIR__."/widgets/home-two-consulting-addon.php");
		require_once (__DIR__."/widgets/lector-counterup-table-addon.php");
		require_once (__DIR__."/widgets/lector-case-studies.php");
		require_once (__DIR__."/widgets/home-two-contact.php");
		require_once (__DIR__."/widgets/pricing-table.php");
		require_once (__DIR__."/widgets/lector-contact-us-addon.php");
		require_once (__DIR__."/widgets/service-custom-post-addon.php");
		require_once (__DIR__."/widgets/lector-case-study-addon.php");

		
		/* Register widget*/
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Comming_Soon_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_About_video_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Counter_Up_Testimonial_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Sponsore_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Newsletter_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Head_Of_Idea_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Testimonial_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Home_One_Banner_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Home_One_Service_One_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Home_One_Client_Video_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Service_Solution_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Home_One_Progress_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Home_One_How_We_Work_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Home_One_Case_Study_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Advisor_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Latest_Blog_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Home_Contact_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Faq_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Advisor_Testimonial_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Consulting_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Counter_Up_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Case_Studies_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Home_Two_Contact_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Pricing_Table_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Contact_Us_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Custom_Post_Service_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Lector_Case_Study_Addon());
	
	}



	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'lector' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'lector' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'lector' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'lector' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'lector' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'lector' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_missing_main_plugin() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'lector' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'lector' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'lector' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );


	}

}
LectorCompanionExtension::instance();



