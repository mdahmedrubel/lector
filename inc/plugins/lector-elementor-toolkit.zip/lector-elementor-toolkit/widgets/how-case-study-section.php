<?php
class Home_One_Case_Study_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_case_study";
	}

	public function get_title() {
		return __( "Case Study", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Case Study Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		$this->add_control(
			'Case_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );	
		$this->add_control(
			'case_sdesc',
			[
				'label' => __('Section Short Discription', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );	
		$this->add_control(
			'case_image',
			[
				'label' => __('Case Study Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
		/*case study section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'case_img',
			[
				'label' => __('Case Slider Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'case_img_url',
			[
				'label' => __('Case Image Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'case_title',
			[
				'label' => __('Case Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'case_title_url',
			[
				'label' => __('Case Title Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'case_content',
			[
				'label' => __('Case Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'task',
			[
				'label' => __('Task Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'task_url',
			[
				'label' => __('Task Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'task_content',
			[
				'label' => __('Task Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );

        $repeater->add_control(
			'action',
			[
				'label' => __('Action Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'action_url',
			[
				'label' => __('Action Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'action_content',
			[
				'label' => __('Action Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'result',
			[
				'label' => __('Result Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'result_url',
			[
				'label' => __('Result Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'result_content',
			[
				'label' => __('Result Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'sections_btn',
			[
				'label' => __('Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'sections_url',
			[
				'label' => __('Button Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'case_groups',
			[
				'label' => __( 'Case Study Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$case_groups = $this->get_settings('case_groups');
	?>
	<!-- case study section start here -->
	<section class="case-study padding-tb" style="background: #f9fafb;">
		<div class="container">
			<div class="row padding-x">
				<div class="case-left">
					<div class="section-header">
						<?php if(!empty($settings['Case_title'])): ?>
							<h2><?php echo esc_html($settings['Case_title']); ?></h2>
						<?php endif; ?>
						<?php if(!empty($settings['case_sdesc'])): ?>
							<p><?php echo esc_html($settings['case_sdesc']); ?></p>
						<?php endif; ?>
					</div>
					<div class="section-wrapper">
						<div class="post-thumb">
							<?php if(!empty($settings['case_image']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['case_image']['url']); ?>" alt="<?php bloginfo('name'); ?>">
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="case-right">
					<div class="case-slider">
						<div class="swiper-wrapper">
							<?php
							if(!empty($case_groups)):
							 foreach($case_groups as $case_group):
							?>
					      	<div class="swiper-slide">
					      		<div class="post-item">
					      			<div class="post-item-inner">
					      				<div class="post-thumb">
					      					<div class="company-logo">
					      						<?php if(!empty($case_group['case_img']['url'])): ?>
					      							<a href="<?php echo esc_url($case_group['case_img_url']); ?>">
														<img src="<?php echo wp_kses_post($case_group['case_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
					      							</a>
					      						<?php endif; ?>
					      					</div>
					      					<div class="company-name">
					      						<?php if(!empty($case_group['case_title'])): ?>
					      							<h3><a href="<?php echo esc_html($case_group['case_title_url']); ?>"><?php echo esc_html($case_group['case_title']); ?></a></h3>
					      						<?php endif; ?>
					      					</div>
					      				</div>
					      				<div class="post-content">
					      					<?php if(!empty($case_group['case_content'])): ?>
					      					<p><?php echo esc_html($case_group['case_content']); ?></p>
					      					<?php endif; ?>
					      					<ul>
					      						<li>
					      							<div class="case-button">
					      								<?php if(!empty($case_group['task'])): ?>
					      								<a href="<?php echo esc_html($case_group['task_url']); ?>"><?php echo esc_html($case_group['task']); ?></a>
					      								<?php endif; ?>
					      							</div>
					      							<div class="case-details">
					      								<?php if(!empty($case_group['task_content'])): ?>
					      								<p><?php echo esc_html($case_group['task_content']); ?></p>
					      								<?php endif; ?>
					      							</div>
					      						</li>
					      						<li>
					      							<div class="case-button">
					      								<?php if(!empty($case_group['action'])): ?>
					      								<a href="<?php echo esc_html($case_group['action_url']); ?>"><?php echo esc_html($case_group['action']); ?></a>
					      								<?php endif; ?>
					      							</div>
					      							<div class="case-details">
					      								<?php if(!empty($case_group['action_content'])): ?>
					      									<p><?php echo esc_html($case_group['action_content']); ?></p>
					      								<?php endif; ?>
					      							</div>
					      						</li>
					      						<li>
					      							<div class="case-button">
					      								<?php if(!empty($case_group['result'])): ?>
					      								<a href="<?php echo esc_html($case_group['result_url']); ?>"><?php echo esc_html($case_group['result']); ?></a>
					      								<?php endif; ?>

					      							</div>
					      							<div class="case-details">
					      								<?php if(!empty($case_group['result_content'])): ?>
					      								<p><?php echo esc_html($case_group['result_content']); ?></p>
					      								<?php endif; ?>

					      							</div>
					      						</li>
					      					</ul>
					      					<?php if(!empty($case_group['sections_btn'])): ?>
					      						<a href="<?php echo esc_url($case_group['sections_url']); ?>" class="text-btn"><?php echo esc_html($case_group['sections_btn']); ?>					      						
					      					</a>
					      					<?php endif; ?>
					      				</div>
					      			</div>
					      		</div>
							</div>
							<?php 
							endforeach;
							endif;
							?>
				      	</div>
				      	<div class="case-pagination"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- case study section ending here -->
	<?php
		
	}


}





