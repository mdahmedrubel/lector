<?php
class Lector_Case_Studies_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_cstudies";
	}

	public function get_title() {
		return __( "Case Study", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Case Study Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'cstudy_title',
			[
				'label' => __('Case Study Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'cstudy_stitle',
			[
				'label' => __('Case Study Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
			
		/*sponsore section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'case_img',
			[
				'label' => __('Case Study Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'case_imgurl',
			[
				'label' => __('Case Study Image Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'case_sub_title',
			[
				'label' => __('Case Study Subtitle', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
        );
        $repeater->add_control(
			'case_title',
			[
				'label' => __('Case Study Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
        );
        $repeater->add_control(
			'case_tlink',
			[
				'label' => __('Case Study Title Link', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
        );
        $repeater->add_control(
			'case_content',
			[
				'label' => __('Case Study Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
        );
        $repeater->add_control(
			'case_btnt',
			[
				'label' => __('Case Study Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
        );
        $repeater->add_control(
			'case_btnurl',
			[
				'label' => __('Case Study Button Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
        );
		$this->add_control(
			'cstudy_groups',
			[
				'label' => __( 'Case Study Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$cstudy_groups = $this->get_settings('cstudy_groups');
	?>
	<!-- case study section start here -->
	<section class="case-study style-2 padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['cstudy_title'])): ?>
					<h2><?php echo esc_html($settings['cstudy_title']); ?></h2>
				<?php endif; ?>
				<?php if(!empty($settings['cstudy_stitle'])): ?>
					<p><?php echo esc_html($settings['cstudy_stitle']); ?></p>
				<?php endif; ?>
			</div>
			<div class="section-wrapper">
				<div class="case-slider2">
					<div class="swiper-wrapper">
						<?php
						if(!empty($cstudy_groups)):
						foreach ($cstudy_groups as $cstudy_group):
						?>
						<div class="swiper-slide">
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-thumb">
										<?php if(!empty($cstudy_group['case_img']['url'])): ?>
										<a href="<?php echo esc_url($cstudy_group['case_imgurl']); ?>">
											<img src="<?php echo wp_kses_post($cstudy_group['case_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
										</a>
										<?php endif; ?>
									</div>
									<div class="post-content">
										<?php if(!empty($cstudy_group['case_sub_title'])): ?>
											<span><?php echo esc_html($cstudy_group['case_sub_title']); ?></span>
										<?php endif; ?>
										<?php if(!empty($cstudy_group['case_title'])): ?>
										<h5>
											<a href="<?php echo esc_url($cstudy_group['case_tlink']); ?>"><?php echo esc_html($cstudy_group['case_title']); ?>
											</a>
										</h5>
										<?php endif; ?>
										<?php if(!empty($cstudy_group['case_content'])): ?>
											<p><?php echo esc_html($cstudy_group['case_content']); ?></p>
										<?php endif; ?>
										<?php if(!empty($cstudy_group['case_btnt'])): ?>
										<a class="simple-button" href="<?php echo esc_url($cstudy_group['case_btnurl']); ?>"><?php echo esc_html($cstudy_group['case_btnt']); ?></a>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
						<?php
						endforeach;
						endif;
						?>
					</div>
					<div class="case-pagination text-center"></div>
				</div>
			</div>
		</div>
	</section>
	<!-- case study section ending here -->
	<?php
		
	}


}





