<?php
class Lector_Pricing_Table_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_pricingtbl";
	}

	public function get_title() {
		return __( "Pricing Table", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Pricing Table Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'pricingt_title',
			[
				'label' => __('Pricing Table Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'pricingt_desc',
			[
				'label' => __('Pricing Table Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
			
		/*Pricing Table section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'package_titel',
			[
				'label' => __('Package Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'package_price',
			[
				'label' => __('Package Price', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'package_stitle',
			[
				'label' => __('Package Sub Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'show_active',
			[
				'label' => __( 'Show Active or Hide Active', 'lector' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show Active', 'lector' ),
				'label_off' => __( 'Hide', 'lector' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'pricing_groups',
			[
				'label' => __( 'Pricing Table Top Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//analytics
		$this->add_control(
			'analytics',
			[
				'label' => __('Analytics Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'analytics_icon',
			[
				'label' => __( 'Icons', 'lector' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'include' => [
					'fas fa-check',
					'fas fa-times',
				],
				'default' => 'fas fa-check',
			]
		);
		$this->add_control(
			'analytic_groups',
			[
				'label' => __( 'Pricing Table Analytics', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//concept
		$this->add_control(
			'concept',
			[
				'label' => __('Concept Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'concept_icon',
			[
				'label' => __( 'Icons', 'lector' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'include' => [
					'fas fa-check',
					'fas fa-times',
				],
				'default' => 'fas fa-check',
			]
		);
		$this->add_control(
			'concept_groups',
			[
				'label' => __( 'Pricing Table Concept', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		//Advise
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'advise_txt',
			[
				'label' => __( 'Advise Title', 'lector' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'advise_groups',
			[
				'label' => __( 'Pricing Table Advise', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//Solutions
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'solution_txt',
			[
				'label' => __( 'Solutions Title', 'lector' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'solution_groups',
			[
				'label' => __( 'Pricing Table Solutions', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//Free support
		$this->add_control(
			'supports',
			[
				'label' => __('Support Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'support_icon',
			[
				'label' => __( 'Support Icons', 'lector' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'include' => [
					'fas fa-check',
					'fas fa-times',
				],
				'default' => 'fas fa-check',
			]
		);
		  $repeater->add_control(
			'icon_bg',
			[
				'label' => __( 'Show Icon Bg', 'lector' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show Bg', 'lector' ),
				'label_off' => __( 'Hide', 'lector' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'support_groups',
			[
				'label' => __( 'Pricing Table Support', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//Discount offer
		$this->add_control(
			'discount',
			[
				'label' => __('Discount Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'discount_icon',
			[
				'label' => __( 'Support Icons', 'lector' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'include' => [
					'fas fa-check',
					'fas fa-times',
				],
				'default' => 'fas fa-check',
			]
		);
		  $repeater->add_control(
			'dis_bg',
			[
				'label' => __( 'Show Icon Bg', 'lector' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show Bg', 'lector' ),
				'label_off' => __( 'Hide', 'lector' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'disc_groups',
			[
				'label' => __( 'Pricing Table Discount Offer', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//data transfer
		$this->add_control(
			'transfer',
			[
				'label' => __('Data Transfer Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'transfer_icon',
			[
				'label' => __( 'Transfer Icons', 'lector' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'include' => [
					'fas fa-check',
					'fas fa-times',
				],
				'default' => 'fas fa-check',
			]
		);
		  $repeater->add_control(
			'data_bg',
			[
				'label' => __( 'Show Icon Bg', 'lector' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show Bg', 'lector' ),
				'label_off' => __( 'Hide', 'lector' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'data_groups',
			[
				'label' => __( 'Pricing Table Data Transfer', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//button
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'sbtn_text',
			[
				'label' => __( 'Button Text', 'lector' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$repeater->add_control(
			'sbtn_url',
			[
				'label' => __( 'Button Url', 'lector' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'active_btn',
			[
				'label' => __( 'Button Active Mode On Off', 'lector' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show Active', 'lector' ),
				'label_off' => __( 'Hide', 'lector' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'butt_groups',
			[
				'label' => __( 'Pricing Table Button', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$price_groups = $this->get_settings('pricing_groups');
		$analytic_groups = $this->get_settings('analytic_groups');
		$concept_groups = $this->get_settings('concept_groups');
		$advise_groups = $this->get_settings('advise_groups');
		$solution_groups = $this->get_settings('solution_groups');
		$support_groups = $this->get_settings('support_groups');
		$disc_groups = $this->get_settings('disc_groups');
		$data_groups = $this->get_settings('data_groups');
		$butt_groups = $this->get_settings('butt_groups');
	?>
	<!-- pricing-section-start -->
	<section class="price padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['pricingt_title'])): ?>
					<h2><?php echo esc_html($settings['pricingt_title']); ?></h2>
				<?php endif;  ?>
                <?php if(!empty($settings['pricingt_desc'])): ?>
					<p><?php echo esc_html($settings['pricingt_desc']); ?></p>
				<?php endif;  ?>
			</div>
			<ul>
				<li class="price-title">
					<div class="data-input"></div>
					<?php
					if(!empty($price_groups)):
						foreach ($price_groups as $price_group):
						?>
						<div class="data-input <?php if ($price_group['show_active'] == 'yes'): echo 'active'; endif; ?>">
							<?php if(!empty($price_group['package_titel'])): ?>
								<h5><?php echo esc_html($price_group['package_titel']); ?></h5>
							<?php endif;  ?>
							<?php if(!empty($price_group['package_price'])): ?>
								<h3><?php echo esc_html($price_group['package_price']); ?></h3>
							<?php endif;  ?>
							<?php if(!empty($price_group['package_stitle'])): ?>
								<p><?php echo esc_html($price_group['package_stitle']); ?></p>
							<?php endif;  ?>
						</div>
						<?php
						endforeach;
					endif;
					?>
				</li>
				<li class="price-body bt">
					<div class="data-input btl">
						<?php if(!empty($settings['analytics'])): echo esc_html($settings['analytics']); endif; ?>
					</div>
					<?php
					if(!empty($analytic_groups)):
					$analytic = 0;
					foreach ($analytic_groups as $analytic_group):
						$analytic++;
					?>
					<div class="data-input">
						<i class="<?php if(!empty($analytic_group['analytics_icon'])): echo esc_attr($analytic_group['analytics_icon']); endif; ?>"></i>
					</div>
					<?php
					if($analytic==3){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-body">
					<div class="data-input">
						<?php if(!empty($settings['concept'])): echo esc_html($settings['concept']); endif; ?>
					</div>
					<?php
					if(!empty($concept_groups)):
					$concept = 0;
					foreach ($concept_groups as $concept_group):
						$concept++;
					?>
					<div class="data-input">
						<i class="<?php if(!empty($concept_group['concept_icon'])): echo esc_attr($concept_group['concept_icon']); endif; ?>"></i>
					</div>
					<?php
					if($concept==3){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-body">
					<?php
					if(!empty($advise_groups)):
					$advise = 0;
					foreach ($advise_groups as $advise_group):
						$advise++;
					?>
					<div class="data-input">
						<?php if(!empty($advise_group['advise_txt'])): echo esc_html($advise_group['advise_txt']); endif; ?>
					</div>
					<?php
					if($advise==4){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-body">
					<?php
					if(!empty($solution_groups)):
					$solution = 0;
					foreach ($solution_groups as $solution_g):
						$solution++;
					?>
					<div class="data-input">
						<?php if(!empty($solution_g['solution_txt'])): echo esc_html($solution_g['solution_txt']); endif; ?>
					</div>
					<?php
					if($solution==4){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-body">
					<div class="data-input">
						<?php if(!empty($settings['supports'])): echo esc_html($settings['supports']); endif; ?>
					</div>
					<?php
					if(!empty($support_groups)):
					$supports = 0;
					foreach ($support_groups as $support_g): 
						$supports++;
					?>
					<div class="data-input">
						<i class="<?php echo esc_html($support_g['support_icon']);?> <?php if($support_g['icon_bg']== 'yes'){echo 'no-bg';}?>"></i>
					</div>
					<?php
					if($supports==3){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-body">
					<div class="data-input">
						<?php if(!empty($settings['discount'])): echo esc_html($settings['discount']); endif; ?>
					</div>
					<?php
					if(!empty($disc_groups)):
					$discounts = 0;
					foreach ($disc_groups as $disc_group): 
						$discounts++;
					?>
					<div class="data-input">
						<i class="<?php echo esc_html($disc_group['discount_icon']);?> <?php if($disc_group['dis_bg']== 'yes'){echo 'no-bg';}?>"></i>
					</div>
					<?php
					if($discounts==3){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-body bb">
					<div class="data-input bbl">
						<?php if(!empty($settings['transfer'])): echo esc_html($settings['transfer']); endif; ?>
					</div>
					<?php
					if(!empty($data_groups)):
					$transfer = 0;
					foreach ($data_groups as $data): 
						$transfer++;
					?>
					<div class="data-input">
						<i class="<?php echo esc_html($data['transfer_icon']);?> <?php if($data['data_bg']== 'yes'){echo 'no-bg';}?>"></i>
					</div>
					<?php
					if($transfer==3){
						break;
					}
					endforeach;
					endif;
					?>
				</li>
				<li class="price-footer">
					<div class="data-input"></div>
					<?php
					if(!empty($butt_groups)):
					$sibutton = 0;
					foreach ($butt_groups as $butt_group): 
						$sibutton++;
					?>
					<div class="data-input">
						<a href="<?php echo esc_url($butt_group['sbtn_url']); ?>" class="price-btn btn <?php if($butt_group['active_btn']){echo 'active'; }?>"><?php echo esc_html($butt_group['sbtn_text']); ?></a>
					</div>
					<?php
					if($sibutton==3){
						break;
					}
					endforeach;
					endif;
					?>
				</li> 

			</ul>
		</div>
	</section>
	<!-- pricing-section-ending -->
	<?php
		
	}


}





