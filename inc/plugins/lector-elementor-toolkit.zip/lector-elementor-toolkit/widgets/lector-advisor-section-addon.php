<?php
class Lector_Advisor_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_advisor";
	}

	public function get_title() {
		return __( "Advisors", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Advisors Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'advisor_title',
			[
				'label' => __('Advisors Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'advisor_stitle',
			[
				'label' => __('Advisors Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
			
		/*Advisors section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'advisor_title',
			[
				'label' => __('Advisors Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'advisor_title_url',
			[
				'label' => __('Advisors Title Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'advisor_position',
			[
				'label' => __('Advisor Position', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'facebook_url',
			[
				'label' => __('Facebook Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'twitter_url',
			[
				'label' => __('Twitter Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'linkedin_url',
			[
				'label' => __('Linkedin Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'advisor_img',
			[
				'label' => __('Advisor Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'advisor_btn',
			[
				'label' => __('Advisor Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'btn_url',
			[
				'label' => __('Advisor Button Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
		$this->add_control(
			'advisor_groups',
			[
				'label' => __( 'Advisors Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$advisor_groups = $this->get_settings('advisor_groups');
	?>
	<!-- advisors section start here -->
	<section class="advisors padding-tb">
		<div class="container">
			<div class="row padding-x">
				<div class="section-wrapper">
					<div class="section-header">
						<?php if(!empty($settings['advisor_title'])): ?>
							<h2><?php echo esc_html($settings['advisor_title']); ?></h2>
						<?php endif; ?>
						<?php if(!empty($settings['advisor_stitle'])): ?>
							<p><?php echo esc_html($settings['advisor_stitle']); ?></p>
						<?php endif; ?>
					</div>
					<div class="advisor-slider">
						<div class="swiper-wrapper">
							<?php
							if(!empty($advisor_groups)):
							 foreach($advisor_groups as $advisor_group):
							?>
					      	<div class="swiper-slide">
					      		<div class="post-item">
					      			<div class="post-item-inner">
					      				<div class="post-thumb">
											<?php if(!empty($advisor_group['advisor_img']['url'])): ?>
												<img src="<?php echo wp_kses_post($advisor_group['advisor_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
											<?php endif; ?>
											<div class="post-content">
												<?php if(!empty($advisor_group['advisor_title'])): ?>
												<h5>
													<a href="<?php echo esc_url($advisor_group['advisor_title_url']['url']); ?>">
														<?php echo esc_html($advisor_group['advisor_title']); ?>
													</a>
												</h5>
												<?php endif; ?>
												<?php if(!empty($advisor_group['advisor_position'])): ?>	
												<span>
													<?php echo esc_html($advisor_group['advisor_position']); ?>
												</span>
												<?php endif; ?>
												<ul>
													<?php if(!empty($advisor_group['facebook_url']['url'])): ?>
														<li><a href="<?php echo esc_url($advisor_group['facebook_url']['url']); ?>"><i class=" fab fa-facebook-f"></i></a></li>
													<?php endif; ?>
													<?php if(!empty($advisor_group['twitter_url']['url'])): ?>
													<li><a href="<?php echo esc_url($advisor_group['twitter_url']['url']); ?>"><i class="fab fa-twitter"></i></a></li>
													<?php endif; ?>
													<?php if(!empty($advisor_group['linkedin_url']['url'])): ?>
													<li><a href="<?php echo esc_url($advisor_group['linkedin_url']['url']); ?>"><i class="fab fa-linkedin-in"></i></a></li>
													<?php endif; ?>
												</ul>
											</div>
											<?php if(!empty($advisor_group['advisor_btn'])): ?>
												<a href="<?php echo esc_url($advisor_group['btn_url']['url']); ?>" class="btn"><?php echo esc_html($advisor_group['advisor_btn']); ?></a>
											<?php endif; ?>
					      				</div>
					      			</div>
					      		</div>
							</div>
							<?php 
							endforeach;
							endif;
							?>
						</div>
						<div class="advisor-pagination"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- advisors section ending here -->
	<?php
		
	}


}





