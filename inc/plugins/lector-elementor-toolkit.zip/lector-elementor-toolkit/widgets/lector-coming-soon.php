<?php
class Lector_Comming_Soon_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_coming_soon";
	}

	public function get_title() {
		return __( "Coming Soon", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Comming Soon Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'soon_bg',
			[
				'label' => __('Coming Soon BG', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$this->add_control(
			'soon_title',
			[
				'label' => __('Coming Soon Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'soon_desc',
			[
				'label' => __('Coming Soon Short Discription', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'soon_day_count',
			[
				'label' => __('Coming Soon Days Count', 'lector'),
				'type' => \Elementor\Controls_Manager::NUMBER,
			]
        );
		$this->add_control(
			'soon_day',
			[
				'label' => __('Coming Soon Days', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'soon_hrs_count',
			[
				'label' => __('Coming Soon Hours Count', 'lector'),
				'type' => \Elementor\Controls_Manager::NUMBER,
			]
        );
		$this->add_control(
			'soon_hrs',
			[
				'label' => __('Coming Soon Hours', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'soon_min_count',
			[
				'label' => __('Coming Soon Minutes Count', 'lector'),
				'type' => \Elementor\Controls_Manager::NUMBER,
			]
        );
		$this->add_control(
			'soon_min',
			[
				'label' => __('Coming Soon Minutes', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'soon_sec_count',
			[
				'label' => __('Coming Soon Second Count', 'lector'),
				'type' => \Elementor\Controls_Manager::NUMBER,
			]
        );
		$this->add_control(
			'soon_sec',
			[
				'label' => __('Coming Soon Second', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'subs_text',
			[
				'label' => __('Subscribe Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'shortcode',
			[
				'label' => __('Subscribe Shortcode', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'facebook_url',
			[
				'label' => __('Facebook Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://facebook.com', 'lector' ),
				'label_block' => true,
			]
        );
		$this->add_control(
			'twitter_url',
			[
				'label' => __('Twitter Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://twitter.com', 'lector' ),
				'label_block' => true,
			]
        );
		$this->add_control(
			'linkdine_url',
			[
				'label' => __('Linkedin Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://linkedin.com', 'lector' ),
				'label_block' => true,
			]
        );
		$this->add_control(
			'youtube_url',
			[
				'label' => __('Youtube Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://youtube.com', 'lector' ),
				'label_block' => true,
			]
        );
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$sectiob_bg = wp_get_attachment_image_src($settings['soon_bg']['id'], 'large');
	?>
	<!-- coming soon section start here -->
	<section class="coming-soon d-flex align-items-center" <?php if(!empty($sectiob_bg)): ?> style="background-image: url(<?php echo esc_url($sectiob_bg[0]); ?>)" <?php endif; ?>>
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-8 col-12">
                    <h2><?php if(!empty($settings['soon_title'])): echo esc_html($settings['soon_title']); endif; ?></h2>
                    <p><?php if(!empty($settings['soon_desc'])): echo esc_html($settings['soon_desc']); endif; ?></p>
                    <ul class="countdown d-flex flex-wrap align-items-center ">
						<li>
							<?php if(!empty($settings['soon_day_count'])): ?>
                            <h3><span class="days"><?php echo esc_html($settings['soon_day_count']); ?></span></h3>
							<?php endif; ?>
							<?php if(!empty($settings['soon_day'])): ?>
							<p class="days_text"><?php echo esc_html($settings['soon_day']); ?></p>
							<?php endif; ?>
						</li>
                        <li>
							<?php if(!empty($settings['soon_hrs_count'])): ?>
							<h3><span class="hours"><?php echo esc_html($settings['soon_hrs_count']); ?></span></h3>
							<?php endif; ?>
							<?php if(!empty($settings['soon_hrs'])): ?>
							<p class="hours_text"><?php echo esc_html($settings['soon_hrs']); ?></p>
							<?php endif; ?>
                        </li>
                        <li>
							<?php if(!empty($settings['soon_min_count'])): ?>
							<h3><span class="minutes"><?php echo esc_html($settings['soon_min_count']); ?></span></h3>
							<?php endif; ?>
							<?php if(!empty($settings['soon_min'])): ?>
							<p class="minu_text"><?php echo esc_html($settings['soon_min']); ?></p>
							<?php endif; ?>
                        </li>
                        <li>
							<?php if(!empty($settings['soon_sec_count'])): ?>
							<h3><span class="seconds"><?php echo esc_html($settings['soon_sec_count']); ?></span></h3>
							<?php endif; ?>
							<?php if(!empty($settings['soon_sec'])): ?>
							<p class="seco_text"><?php echo esc_html($settings['soon_sec']); ?></p>
							<?php endif; ?>
                        </li>
                    </ul>
                    <div class="news-letter">
                        <div class="section-wrapper">
                            <p class="notify"><?php if(!empty($settings['subs_text'])): echo esc_html($settings['subs_text']); endif; ?></p>
                            <div class="recent-news comingsoon">
								<?php 
								if(!empty($settings['shortcode'])):
									echo do_shortcode($settings['shortcode']); 
								endif;
								?>
                            </div>
                            <ul class="social-media-icons">
								<?php if(!empty($settings['facebook_url']['url'])): ?>
                                <li>
                                    <a class="facebook" href="<?php echo esc_url($settings['facebook_url']['url']); ?>"><i class="fab fa-facebook-f"></i></a>
                                </li>
								<?php endif; ?>
								<?php if(!empty($settings['twitter_url']['url'])): ?>
                                <li>
                                    <a class="twitter" href="<?php echo esc_url($settings['twitter_url']['url']); ?>"><i class="fab fa-twitter"></i></a>
                                </li>
								<?php endif; ?>
								<?php if(!empty($settings['linkdine_url']['url'])): ?>
                                <li>
                                    <a class="linkedin" href="<?php echo esc_url($settings['linkdine_url']['url']); ?>"><i class="fab fa-linkedin-in"></i></a>
                                </li>
								<?php endif; ?>
								<?php if(!empty($settings['youtube_url']['url'])): ?>
                                <li>
                                    <a class="youtube" href="<?php echo esc_url($settings['youtube_url']['url']); ?>"><i class="fab fa-youtube"></i></a>
                                </li>
								<?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- coming soon section ending here -->
	<?php
		
	}


}





