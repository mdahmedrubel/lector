<?php
class Lector_Home_One_Service_One_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_service_one";
	}

	public function get_title() {
		return __( "Services", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Service Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		/*service section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'service_icon',
			[
				'label' => __('Service Icon', 'lector'),
				'type' => \Elementor\Controls_Manager::ICON,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'service_title',
			[
				'label' => __('Service Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'service_sdesc',
			[
				'label' => __('Service Short Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'service_url',
			[
				'label' => __('Service Short Content', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
		$this->add_control(
			'Service_groups',
			[
				'label' => __( 'Service Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$Service_groups = $this->get_settings('Service_groups');
	?>
	<!-- services section start here -->
	<section class="services">
		<div class="container">
			<div class="row padding-x">
				<div class="section-wrapper">
					<div class="services-slider">
					    <div class="swiper-wrapper">
					    	<?php 
					    	if(!empty($Service_groups)):
					    	foreach($Service_groups as $Service_group):
					    	?>
					      	<div class="swiper-slide">
								<div class="post-item">
									<div class="post-item-inner">
										<div class="post-thumb">
											<div class="round-1">
												<div class="services-circle-wrapper">
													<div class="services-circle"></div>
												</div>
												<div class="services-circle-wrapper">
													<div class="services-circle"></div>
												</div>
											</div>
											<div class="round-2"></div>
											<div class="service-icon">
												<?php if(!empty($Service_group['service_icon'])): ?>
													<i class="<?php echo esc_attr($Service_group['service_icon']); ?>"></i>
												<?php endif; ?>
											</div>
										</div>
										<div class="post-content">
											<?php if(!empty($Service_group['service_title'])): ?>
											<h5><?php echo esc_html($Service_group['service_title']); ?></h5>
											<?php endif; ?>
											<?php if(!empty($Service_group['service_sdesc'])): ?>
											<p><?php echo esc_html($Service_group['service_sdesc']); ?></p>
											<?php endif; ?>
											<?php if(!empty($Service_group['service_url']['url'])): ?>
											<a href="<?php echo esc_url($Service_group['service_url']['url']); ?>" class="service-flaticon flaticon-next"></a>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php 
							endforeach;
							endif;
							?>
						</div>
					</div>
				</div>
				<div class="services-pagination"></div>
			</div>
		</div>
	</section>
	<!-- services section ending here -->
	<?php
		
	}


}





