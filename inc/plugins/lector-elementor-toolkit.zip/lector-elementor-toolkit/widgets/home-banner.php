<?php
class Lector_Home_One_Banner_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_banner_one";
	}

	public function get_title() {
		return __( "Banner One", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Banner Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_banner',[
				'label' => __( 'Select Banner Style', 'lector' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-one',
				'label_block' => true,
				'options' => [
					'style-one'  => __( 'Home One Banner', 'lector' ),
					'style-two'  => __( 'Home Two Banner', 'lector' ),
				],
			]
        );
        $this->add_control(
			'banner_title',
			[
				'label' => __('Banner Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		); 
		$this->add_control(
			'banner_stitle',
			[
				'label' => __('Banner Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		); 
		$this->add_control(
			'banner_shortcode',
			[
				'label' => __('Banner ShortCode', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);	
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Section Background', 'lector' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .banner',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);	

		//banner two content
		$this->add_control(
			'banner2_title',
			[
				'label' => __('Banner Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner2_sdesc',
			[
				'label' => __('Banner Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner2_btn',
			[
				'label' => __('Banner Two Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner2_url',
			[
				'label' => __('Banner Two Button Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		); 
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'Banner background',
				'label' => __( 'Section Background', 'lector' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .banner.style-2',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);	 	
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- banner section start here -->
	<?php 
	if($settings['choose_banner'] == 'style-one'):	
	?>
	<section class="banner">
		<div class="banner-area">
			<div class="container">
				<div class="row padding-x">
					<div class="banner-content">
						<?php if(!empty($settings['banner_title'])): ?>
						<h2 class="banner-text"><?php echo esc_html($settings['banner_title']); ?></h2>
						<?php endif; ?>
						<?php if(!empty($settings['banner_stitle'])): ?>
						<p class="banner-desc"><?php echo esc_html($settings['banner_stitle']); ?></p>
						<?php endif; ?>
						<?php
							if(!empty($settings['banner_shortcode'])):
							  echo do_shortcode($settings['banner_shortcode']);
							endif; 
						?> 
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
	elseif($settings['choose_banner'] == 'style-two'): 
	?>
	<section class="banner style-2">
		<div class="banner-area">
			<div class="container">
				<div class="row padding-x">
					<div class="banner-content">
						<?php if(!empty($settings['banner2_title'])): ?>
						<h2 class="banner-text"><?php echo esc_html($settings['banner2_title']); ?></h2>
						<?php endif; ?>
						<?php if(!empty($settings['banner2_sdesc'])): ?>
						<p class="banner-desc"><?php echo esc_html($settings['banner2_sdesc']); ?></p>
						<?php endif; ?>
						<?php if(!empty($settings['banner2_btn'])): ?>
						<a href="<?php echo esc_url($settings['banner2_url']['url']); ?>" class="btn"><?php echo esc_html($settings['banner2_btn']); ?></a>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php 
	endif;
	?>
	<!-- banner section ending here -->
	<?php
		
	}


}





