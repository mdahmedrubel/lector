<?php
class Lector_Testimonial_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_testimonial";
	}

	public function get_title() {
		return __( "Testimonial", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Testimonial Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'section_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'testi_image',
			[
				'label' => __('Testimonial Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		); 
        $repeater->add_control(
			'testi_cont',
			[
				'label' => __('Testimonial Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		); 
        $repeater->add_control(
			'testi_author',
			[
				'label' => __('Testimonial Author Name', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);  
        $repeater->add_control(
			'author_url',
			[
				'label' => __('Testimonial Author Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
			]
		); 
        $repeater->add_control(
			'testi_author_position',
			[
				'label' => __('Testimonial Author Position', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'testi_groups',
			[
				'label' => __( 'Testimonial Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'btntesti_image',
			[
				'label' => __('Testimonial Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);  
        $repeater->add_control(
			'btntesti_author',
			[
				'label' => __('Testimonial Author Name', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
        $repeater->add_control(
			'btntesti_author_position',
			[
				'label' => __('Testimonial Author Position', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'btntesti_groups',
			[
				'label' => __( 'Testimonial Button Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
	
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$testi_groups = $this->get_settings('testi_groups');
		$btntesti_groups = $this->get_settings('btntesti_groups');
	?>
	<!-- testimonial section start here -->
    <section class="testimonial style-2 padding-tb">
        <div class="container">
            <div class="section-header">
            	<?php if(!empty($settings['section_title'])): ?>
                <h2><?php echo $settings['section_title']; ?></h2>
            	<?php endif; ?>
            </div>
            <div class="section-wrapper">
                <div class="tab-content">
                	<?php
                	$count = 0;
                	if(!empty($testi_groups)): 
	                	foreach($testi_groups as $testi_group):
	                		$count++;
	                	?>
						<div class="tab-pane <?php if(1 == $count) echo _e('active', 'lector'); ?>" id="one-<?php echo esc_attr($count); ?>">
							<div class="post-item">
								<div class="post-thumb">
									<?php if(!empty($testi_group['testi_image']['url'])): ?>
										<img src="<?php echo wp_kses_post($testi_group['testi_image']['url']); ?>" alt="<?php bloginfo('name'); ?>">
									<?php endif; ?>
								</div>
								<?php if(!empty($testi_group['testi_cont'])): ?>
									<p><?php echo $testi_group['testi_cont']; ?></p>
								<?php endif; ?>
								<h6>
									<a href="<?php if(!empty($testi_group['author_url']['url'])): echo esc_url($testi_group['author_url']['url']); endif; ?>">
										<?php if(!empty($testi_group['testi_author'])): ?>
										<?php echo esc_html($testi_group['testi_author']); ?>	
										<?php endif; ?>
									</a>
									<?php if(!empty($testi_group['testi_author_position'])): ?>
									<span>
										<?php echo esc_html($testi_group['testi_author_position']); ?>	
									</span>
									<?php endif; ?>
								</h6>
							</div>
						</div>
						<?php
						 endforeach; 
					endif;	
					?>
				</div>
				<ul class="nav nav-tabs" role="tablist">
					<?php
                	$count = 0;
                	if(!empty($btntesti_groups)):  
	                	foreach($btntesti_groups as $btntesti_group):
	                		$count++;
	                	?>
						<li class="<?php if(1 == $count) echo _e('active', 'lector'); ?> flaticon-upload">
							<a href="#one-<?php echo esc_attr($count); ?>" class="<?php if(1 == $count) echo _e('active', 'lector'); ?>" role="tab" data-toggle="tab">
								<div class="post-thumb">
									<?php if(!empty($btntesti_group['btntesti_image']['url'])): ?>
										<img src="<?php echo wp_kses_post($btntesti_group['btntesti_image']['url']); ?>" alt="<?php bloginfo('name'); ?>">
									<?php endif; ?>
								</div>
								<h6>
									<?php
									if(!empty($btntesti_group['btntesti_author'])):
									 echo esc_html($btntesti_group['btntesti_author']); 
									endif;
									?>
									<?php if(!empty($btntesti_group['btntesti_author_position'])): ?>
									<span>
										<?php echo esc_html($btntesti_group['btntesti_author_position']); ?>	
									</span>
									<?php endif; ?>
								</h6>
							</a>
						</li>
						<?php
						 endforeach; 
					endif;
					?>
				</ul>
            </div>
        </div>
    </section>
    <!-- testimonial section ending here -->
	<?php
		
	}


}





