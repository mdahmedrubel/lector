<?php
class Lector_Home_Two_Contact_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_h2contact";
	}

	public function get_title() {
		return __( "Home Contact Two", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Contact Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'h2contact_title',
			[
				'label' => __('Contact Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'h2contact_stitle',
			[
				'label' => __('Contact Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'h2contact_shortcode',
			[
				'label' => __('Contact ShortCode', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
	
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- contact us section start here -->
	<section class="contact">
		<div class="container">
			<div class="section-wrapper row">
				<div class="col-lg-4 col-12">
					<div class="section-header">
						<?php if(!empty($settings['h2contact_title'])): ?>
							<h3>
							    <?php
							    echo esc_html($settings['h2contact_title']); 
							    ?>
							</h3>
						<?php endif;  ?>
		                <?php if(!empty($settings['h2contact_stitle'])): ?>
							<p>
							   <?php
							   echo esc_html($settings['h2contact_stitle']); 
							   ?>
							</p>
						<?php endif;  ?>
					</div>
				</div>
				<div class="col-lg-8 col-12">
					<div class="contact-form home-two">
						<?php
						if(!empty($settings['h2contact_shortcode'])):
						 echo do_shortcode($settings['h2contact_shortcode']);
						endif; 
						?> 
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- contact us section ending here -->
	<?php
		
	}


}





