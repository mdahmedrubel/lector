<?php
class Lector_Home_Contact_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_home_contact";
	}

	public function get_title() {
		return __( "Home Support", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Contact Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'hcontact_title',
			[
				'label' => __('Contact Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'hcontactr_stitle',
			[
				'label' => __('Contact Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'contact_img',
			[
				'label' => __('Contact Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		); 
		$this->add_control(
			'contact_ltitle',
			[
				'label' => __('Contact Left Title', 'lector'),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);
		$this->add_control(
			'contact_ldesc',
			[
				'label' => __('Contact Left Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'hcontact_shortcode',
			[
				'label' => __('Contact ShortCode', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
	
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- support section start here -->
	<section class="support padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['hcontact_title'])): ?>
					<h2><?php echo esc_html($settings['hcontact_title']); ?></h2>
				<?php endif; ?>
				<?php if(!empty($settings['hcontactr_stitle'])): ?>
					<p>
					    <?php echo wp_kses_post($settings['hcontactr_stitle']); ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="section-wrapper">
				<div class="contact-member">
					<div class="post-thumb">
						<?php if(!empty($settings['contact_img']['url'])): ?>
							<img src="<?php echo wp_kses_post($settings['contact_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
						<?php endif; ?>
					</div>
				</div>
				<div class="contact-us">
					<div class="section-header">
						<?php if(!empty($settings['contact_ltitle'])): ?>
							<h4><?php echo wp_kses_post($settings['contact_ltitle']); ?></h4>
						<?php endif; ?>
						<?php if(!empty($settings['contact_ldesc'])): ?>
							<p>
							    <?php echo esc_html($settings['contact_ldesc']); ?>
							</p>
						<?php endif; ?>
					</div>
                    <?php
                    if(!empty($settings['hcontact_shortcode'])):
                      echo do_shortcode($settings['hcontact_shortcode']); 
                  	endif;
                    ?>
				</div>
			</div>
		</div>
	</section>
	<!-- support section ending here -->
	<?php
		
	}


}





