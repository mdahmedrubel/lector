<?php
class Lector_Faq_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_faq";
	}

	public function get_title() {
		return __( "Lector Faqs", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Faqs Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'faq_title',
			[
				'label' => __('Faqs Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'faq_sdesc',
			[
				'label' => __('Faqs Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);

		//tab button
		$this->add_control(
			'tabbtn_gropus',[
				'label' => __( 'Tab Button Text.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'tab_btn',
                        'label' => esc_html__('Button Text', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		//general left tab content
		$this->add_control(
			'general_left',[
				'label' => __( 'General Left Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'left_question',
                        'label' => esc_html__('General Left Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'left_answer',
                        'label' => esc_html__('General Left Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		//general right tab content
		$this->add_control(
			'general_right',[
				'label' => __( 'General Right Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'right_question',
                        'label' => esc_html__('General Right Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'right_answer',
                        'label' => esc_html__('General Right Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		//service tab content
		$this->add_control(
			'service_right',[
				'label' => __( 'Service Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'service_question',
                        'label' => esc_html__('Service Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'service_answer',
                        'label' => esc_html__('Service Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		//payment tab content
		$this->add_control(
			'payment_left',[
				'label' => __( 'Payment Left Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'pleft_question',
                        'label' => esc_html__('Payment Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'pleft_answer',
                        'label' => esc_html__('Payment Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		$this->add_control(
			'payment_right',[
				'label' => __( 'Payment Right Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'pright_question',
                        'label' => esc_html__('Payment Right Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'pright_answer',
                        'label' => esc_html__('Payment Right Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);


		//account tab content
		$this->add_control(
			'account_left',[
				'label' => __( 'Account Left Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'aleft_question',
                        'label' => esc_html__('Account Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'aleft_answer',
                        'label' => esc_html__('Account Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		$this->add_control(
			'account_right',[
				'label' => __( 'Account Right Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'aright_question',
                        'label' => esc_html__('Account Right Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'aright_answer',
                        'label' => esc_html__('Account Right Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		//features tab content
		$this->add_control(
			'feature_left',[
				'label' => __( 'Features Left Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'fleft_question',
                        'label' => esc_html__('Features Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'fleft_answer',
                        'label' => esc_html__('Features Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		$this->add_control(
			'feature_right',[
				'label' => __( 'Features Right Content.', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [ 
                    [
                        'name' => 'fright_question',
                        'label' => esc_html__('Features Right Question', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'fright_answer',
                        'label' => esc_html__('Features Right Answer', 'lector'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);



			
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$tabbtn_gropus = $this->get_settings('tabbtn_gropus');
		$general_groups = $this->get_settings('general_left');
		$general_right = $this->get_settings('general_right');
		$service_right = $this->get_settings('service_right');
		$payment_left = $this->get_settings('payment_left');
		$payment_right = $this->get_settings('payment_right');
		$account_left = $this->get_settings('account_left');
		$account_right = $this->get_settings('account_right');
		$feature_left = $this->get_settings('feature_left');
		$feature_right = $this->get_settings('feature_right');
	?>
	<!-- faq section start here -->
	<section class="faq padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['faq_title'])): ?>
					<h2><?php echo esc_html($settings['faq_title']); ?></h2>
				<?php endif;  ?>
                <?php if(!empty($settings['faq_sdesc'])): ?>
					<p><?php echo esc_html($settings['faq_sdesc']); ?></p>
				<?php endif;  ?>
			</div>
			<div class="section-wrapper">
				<ul class="tabs">
					<?php
					$tab_count = 0;
					if(!empty($tabbtn_gropus)):
					 foreach($tabbtn_gropus as $tabbtn_gropu): 
					 	$tab_count++;
					?>
					<li class="tab-link <?php if(1 == $tab_count) echo _e('current', 'lector'); ?>" data-tab="tab-<?php echo esc_attr($tab_count); ?>"><?php if(!empty($tabbtn_gropu['tab_btn'])): echo esc_html($tabbtn_gropu['tab_btn']); endif; ?></li>
					<?php
					 endforeach; 
					endif;
					?>
				</ul>

				<div id="tab-1" class="tab-content current">
					<div class="faq-fil-list">
						<div class="col-lg-6">
							<?php
							$general = 0;
							if(!empty($general_groups)):
							 foreach($general_groups as $general_group): 
							 	$general++;
							?>
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question <?php if(1 == $general) echo _e('in', 'lector'); ?>">
											<div class="accordion-icon"></div>
											<?php if(!empty($general_group['left_question'])): ?>
												<h6><?php echo esc_html($general_group['left_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer <?php if(1 == $general) echo _e('active', 'lector'); ?>">
											<?php if(!empty($general_group['left_answer'])): ?>
												<p><?php echo esc_html($general_group['left_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
						<div class="col-lg-6">
							<?php
							if(!empty($general_right)):
							 foreach($general_right as $general_righ): 
							?>
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question">
											<div class="accordion-icon"></div>
											<?php if(!empty($general_righ['right_question'])): ?>
												<h6><?php echo esc_html($general_righ['right_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer">
											<?php if(!empty($general_righ['right_answer'])): ?>
											<p><?php echo esc_html($general_righ['right_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
					</div>
				</div>
				<div id="tab-2" class="tab-content">
					<div class="faq-fil-list">
						<div class="col-lg-6">	
							<?php
							$servic = 0;
							if(!empty($service_right)):
							 foreach($service_right as $service):
							 $servic++; 
							?>
							<div class="post-item bg-white">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question <?php if(1 == $servic) echo _e('in', 'lector'); ?>">
											<div class="accordion-icon"></div>
											<?php if(!empty($service['service_question'])): ?>
												<h6><?php echo esc_html($service['service_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer <?php if(1 == $servic) echo _e('active', 'lector'); ?>">
											<?php if(!empty($service['service_answer'])): ?>
											<p><?php echo esc_html($service['service_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
						<div class="col-lg-6"></div>
					</div>
				</div>
				<div id="tab-3" class="tab-content">
					<div class="faq-fil-list">
						<div class="col-lg-6">
							<?php
							$payment = 0;
							if(!empty($payment_left)):
							 foreach($payment_left as $payment):
							 $payment++; 
							?>
							<div class="post-item bg-white">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question <?php if(1 == $payment) echo _e('in', 'lector'); ?>">
											<div class="accordion-icon"></div>
											<?php if(!empty($payment['pleft_question'])): ?>
												<h6><?php echo esc_html($payment['pleft_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer <?php if(1 == $payment) echo _e('active', 'lector'); ?>">
											<?php if(!empty($payment['pleft_answer'])): ?>
											<p><?php echo esc_html($payment['pleft_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
						<div class="col-lg-6">
							<?php
							if(!empty($payment_right)):
							 foreach($payment_right as $payment_rig):
							?>
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question">
											<div class="accordion-icon"></div>
											<?php if(!empty($payment_rig['pright_question'])): ?>
												<h6><?php echo esc_html($payment_rig['pright_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer">
											<?php if(!empty($payment_rig['pright_answer'])): ?>
											<p><?php echo esc_html($payment_rig['pright_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
					</div>
				</div>
				<div id="tab-4" class="tab-content">
					<div class="faq-fil-list">
						<div class="col-lg-6">
							<?php
							if(!empty($account_left)):
							$account = 0; 
							 foreach($account_left as $accounts):
							 	$account++;
							?>
							<div class="post-item bg-white">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question <?php if(1 == $account) echo _e('in', 'lector'); ?>">
											<div class="accordion-icon"></div>
											<?php if(!empty($accounts['aleft_question'])): ?>
												<h6><?php echo esc_html($accounts['aleft_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer <?php if(1 == $account) echo _e('active', 'lector'); ?>">
											<?php if(!empty($accounts['aleft_answer'])): ?>
											<p><?php echo esc_html($accounts['aleft_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
						<div class="col-lg-6">
							<?php
							if(!empty($account_right)):
							 foreach($account_right as $account_rig):
							?>
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question">
											<div class="accordion-icon"></div>
											<?php if(!empty($account_rig['aright_question'])): ?>
												<h6><?php echo esc_html($account_rig['aright_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer">
											<?php if(!empty($account_rig['aright_answer'])): ?>
												<p><?php echo esc_html($account_rig['aright_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
					</div>
				</div>
				<div id="tab-5" class="tab-content">
					<div class="faq-fil-list">
						<div class="col-lg-6">
							<?php
							if(!empty($feature_left)):
							$features = 0;
							 foreach($feature_left as $feature):
							 	$features++;
							?>
							<div class="post-item bg-white">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question <?php if(1 == $features) echo _e('in', 'lector'); ?>">
											<div class="accordion-icon"></div>
											<?php if(!empty($feature['fleft_question'])): ?>
												<h6><?php echo esc_html($feature['fleft_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer <?php if(1 == $features) echo _e('active', 'lector'); ?>">
											<?php if(!empty($feature['fleft_answer'])): ?>
												<p><?php echo esc_html($feature['fleft_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
						<div class="col-lg-6">
							<?php
							if(!empty($feature_right)):
							 foreach($feature_right as $feature_rig):
							?>
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-content">
										<div class="accordion-question">
											<div class="accordion-icon"></div>
											<?php if(!empty($feature_rig['fright_question'])): ?>
												<h6><?php echo esc_html($feature_rig['fright_question']); ?></h6>
											<?php endif; ?>
										</div>
										<div class="accordion-answer">
											<?php if(!empty($feature_rig['fright_answer'])): ?>
												<p><?php echo esc_html($feature_rig['fright_answer']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							 endforeach; 
							endif;
							?>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- faq section ending here -->
	<?php
		
	}


}





