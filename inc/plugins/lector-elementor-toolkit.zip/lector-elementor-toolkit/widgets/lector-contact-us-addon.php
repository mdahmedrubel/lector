<?php
class Lector_Contact_Us_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_contactus";
	}

	public function get_title() {
		return __( "Contact Us", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Contact Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'contact_title',
			[
				'label' => __('Contact Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'contact_shortcode',
			[
				'label' => __('Contact Shortcode', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'start_date',
			[
				'label' => __('Working Day', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'close_date',
			[
				'label' => __('Close Time', 'lector'),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);
		$this->add_control(
			'address_title',
			[
				'label' => __('Address Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'caddress',
			[
				'label' => __('Contact Address', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'caddress2',
			[
				'label' => __('Contact Address Line Two', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'google_map',
			[
				'label' => __('Google Map Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'google_mapurl',
			[
				'label' => __('Google Map Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'cemail',
			[
				'label' => __('Email Here', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'cmobile',
			[
				'label' => __('Mobile Number Here', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'fb_url',
			[
				'label' => __('Facebook Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);
		$this->add_control(
			't_url',
			[
				'label' => __('Twitter Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);
		$this->add_control(
			'l_url',
			[
				'label' => __('Linkedin Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);
		$this->add_control(
			'yo_url',
			[
				'label' => __('Youtube Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$csocials = $this->get_settings('csocial_groups');
	?>
	<!-- contact us section start here -->
    <div class="contact style-2 padding-tb">
        <div class="container">
            <div class="section-wrapper row justify-content-center">
                <div class="col-lg-8 col-12">
                    <div class="contact-part">
                        <div class="contact-title">
                        	<?php if(!empty($settings['contact_title'])): ?>
                            	<h4><?php echo esc_html($settings['contact_title']); ?></h4>
                        	<?php endif; ?>
                        </div>
                        <div class="contact-form contact-css d-flex flex-wrap justify-content-between">
                        	<?php
                        	if(!empty($settings['contact_shortcode'])):
                        	 echo do_shortcode($settings['contact_shortcode']); 
                        	endif;
                        	?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="info-part">
                        <ul class="schedule">
                        	<?php if(!empty($settings['start_date'])): ?>
                            	<li> <i class="far fa-clock"></i><?php echo esc_html($settings['start_date']); ?></li>
                            <?php endif; ?>
                            <?php if(!empty($settings['close_date'])): ?>
                            	<li><i class="fas fa-lock"></i><?php echo wp_kses_post($settings['close_date']); ?></li>
                            <?php endif; ?>
                        </ul>
                        <div class="contact-info">
                        	<?php if(!empty($settings['address_title'])): ?>
                            	<h4><?php echo esc_html($settings['address_title']); ?></h4>
                            <?php endif; ?>
                            <?php if(!empty($settings['caddress'])): ?>
                            	<p><?php echo esc_html($settings['caddress']); ?></p>
                            <?php endif; ?>
                            <?php if(!empty($settings['caddress2'])): ?>
                            	<p class="style-2"><?php echo esc_html($settings['caddress2']); ?></p>
                        	<?php endif; ?>
                        	<?php if(!empty($settings['google_map'])): ?>
                            	<a href="<?php echo esc_url($settings['google_mapurl']); ?>"><?php echo esc_html($settings['google_map']); ?></a>
                            <?php endif; ?>
                            <ul class="details">
                            	<?php if(!empty($settings['cemail'])): ?>
                                <li>
                                    <p><?php esc_html_e('Email', 'lector'); ?></p>
                                    <?php echo esc_html($settings['cemail']); ?>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($settings['cmobile'])): ?>
                                <li>
                                    <p><?php esc_html_e('Phone', 'lector'); ?></p>
                                    <?php echo esc_html($settings['cmobile']); ?>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <ul class="social-media-icons">
                            	<?php if(!empty($settings['fb_url']['url'])): ?>
                            	<li>
                                    <a class="facebook" href="<?php echo esc_url($settings['fb_url']['url']); ?>"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($settings['t_url']['url'])): ?>
                                <li>
                                    <a class="twitter" href="<?php echo esc_url($settings['t_url']['url']); ?>"><i class="fab fa-twitter"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($settings['l_url']['url'])): ?>
                                <li>
                                    <a class="linkedin" href="<?php echo esc_url($settings['l_url']['url']); ?>"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if(!empty($settings['yo_url']['url'])): ?>
                                <li>
                                    <a class="youtube" href="<?php echo esc_url($settings['yo_url']['url']); ?>"><i class="fab fa-youtube"></i></a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- contact us section ending here -->
	<?php
		
	}


}





