<?php
class Lector_Head_Of_Idea_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_head_of_idea";
	}

	public function get_title() {
		return __( "Head Of Idea", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Head Of Ideas Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'ideas_title',
			[
				'label' => __('Head Of Ideas Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
        $this->add_control(
			'ideas_title2',
			[
				'label' => __('Head Of Ideas Title Part Two', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		/*sponsore section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'idea_head',
			[
				'label' => __('Head Of Ideas Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'image_url',
			[
				'label' => __('Head Of Ideas Image Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'idea_name',
			[
				'label' => __('Head Of Ideas Name', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'idea_name_url',
			[
				'label' => __('Head Of Ideas Name Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'idea_position',
			[
				'label' => __('Head Of Ideas Position', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'social_share1',
			[
				'label' => __('Head Of Ideas Facebook Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'social_share2',
			[
				'label' => __('Head Of Ideas Twitter Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'social_share3',
			[
				'label' => __('Head Of Ideas Instagram Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
		$this->add_control(
			'ideas_groups',
			[
				'label' => __( 'Head Of Ideas Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$ideas_groups = $this->get_settings('ideas_groups');
	?>
	<!-- our business plan section start here -->
	<section class="advisors style-3 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <div class="round-one">
	                <div class="footer-circle-wrapper">
	                    <div class="footer-circle"></div>
	                </div>
	                <div class="footer-circle-wrapper">
	                    <div class="footer-circle"></div>
	                </div>
	            </div>
	            <div class="round-two"></div>
	            <div class="round-three"></div>
	            <div class="style-two">
	            	<?php if(!empty($settings['ideas_title'])): ?>
	                <h2><?php echo esc_html($settings['ideas_title']); ?></h2>
	            	<?php endif; ?>
					<?php if(!empty($settings['ideas_title2'])): ?>
	                <h2><?php echo esc_html($settings['ideas_title2']); ?></h2>
	            	<?php endif; ?>
	                <div class="advisor-navigation">
	                    <div class="advisor-prev"><i class="flaticon-back"></i></div>
	                    <div class="advisor-next"><i class="flaticon-next"></i></div>
	                </div>
	            </div>
	        </div>
	        <div class="section-wrapper">
	            <div class="advisor-slider_2">
	                <div class="swiper-wrapper">
	                	<?php
	                	if(!empty($ideas_groups)):
	                	foreach ($ideas_groups as $ideas_group): 
	                	?>
	                    <div class="swiper-slide">
	                        <div class="post-item">
	                            <div class="post-thumb">
	                            	<?php if(!empty($ideas_group['idea_head']['url'])): ?>			
	                                <a href="<?php echo esc_url($ideas_group['image_url']['url']); ?>">
	                                	<img src="<?php echo wp_kses_post($ideas_group['idea_head']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                                </a>
	                                <?php endif; ?>
	                            </div> 
	                            <div class="post-content">
	                            	<?php if(!empty($ideas_group['idea_name'])): ?>
	                                <h5><a href="<?php echo esc_url($ideas_group['idea_name_url']['url']); ?>"><?php echo esc_html($ideas_group['idea_name']); ?></a></h5>
	                                <?php endif; ?>
	                                <?php if(!empty($ideas_group['idea_position'])): ?>
	                                <p><?php echo esc_html($ideas_group['idea_position']); ?></p>
	                                <?php endif; ?>
	                                <ul class="d-flex flex-wrap justify-content-center">
	                                	<?php if(!empty($ideas_group['social_share1']['url'])): ?>
	                                    <li>
	                                        <a href="<?php echo esc_url($ideas_group['social_share1']['url']); ?>"><i class="fab fa-facebook-f"></i></a>
	                                    </li>
	                                    <?php endif; ?>
	                                    <?php if(!empty($ideas_group['social_share2']['url'])): ?>
	                                    <li>
	                                        <a href="<?php echo esc_url($ideas_group['social_share2']['url']); ?>"><i class="fab fa-twitter"></i></a>
	                                    </li>
	                                    <?php endif; ?>
	                                    <?php if(!empty($ideas_group['social_share3']['url'])): ?>
	                                    <li>
	                                        <a href="<?php echo esc_url($ideas_group['social_share3']['url']); ?>"><i class="fab fa-instagram"></i></a>
	                                    </li>
	                                    <?php endif; ?>
	                                </ul>  
	                            </div>
	                        </div>
	                    </div>
	                	<?php
	                	 endforeach;
	                	 endif; 
	                	?>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- our business plan section ending here -->
	<?php
		
	}


}





