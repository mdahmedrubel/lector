<?php
class Lector_Counter_Up_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_counterup";
	}

	public function get_title() {
		return __( "Counter Up", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Counter Up Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			
		/*sponsore section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'counter_ups',
			[
				'label' => __('Counter Up Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'counter_number',
			[
				'label' => __('Counter Up Number', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'counter_symble',
			[
				'label' => __('Counter Up Symble', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'counter_btitle',
			[
				'label' => __('Counter Up Bottom Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'counter_groups',
			[
				'label' => __( 'Counter Up Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$counter_groups = $this->get_settings('counter_groups');
	?>
	<!-- counter-up section ending here -->
	<section class="counter-up style-2">
		<div class="container">
			<div class="row">
				<div class="counter-area">
					<ul>
						<?php
						if(!empty($counter_groups)):
						 foreach($counter_groups as $counter_group): 
						?>
						<li>
							<div class="post-thumb">
								<div class="post-inner">
									<?php if(!empty($counter_group['counter_ups']['url'])): ?>
										<img src="<?php echo wp_kses_post($counter_group['counter_ups']['url']); ?>" alt="<?php bloginfo('name'); ?>">
									<?php endif; ?>
								</div>
							</div>
							<div class="post-content">
								<?php if(!empty($counter_group['counter_number'])): ?>
								<h3>
									<span class="counter"><?php echo esc_html($counter_group['counter_number']); ?></span>
									<?php echo esc_html($counter_group['counter_symble']); ?>
								</h3>
								<?php endif; ?>
								<?php if(!empty($counter_group['counter_btitle'])): ?>
									<p><?php echo esc_html($counter_group['counter_btitle']); ?></p>
								<?php endif; ?>
							</div>
						</li>
						<?php
						 endforeach;
						endif;
						?>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<!-- counter-up section ending here -->
	<?php
		
	}


}





