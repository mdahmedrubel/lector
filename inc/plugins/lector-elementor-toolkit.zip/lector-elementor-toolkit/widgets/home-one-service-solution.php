<?php
class Service_Solution_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_service_solution";
	}

	public function get_title() {
		return __( "Service Solution", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Service Solution Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		$this->add_control(
			'choose_service',[
				'label' => __( 'Select Service Solution Style', 'lector' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-one',
				'label_block' => true,
				'options' => [
					'style-one'  => __( 'Service Solution Style One', 'lector' ),
					'style-two'  => __( 'Service Solution Style Two', 'lector' ),
				],
			]
        );
		$this->add_control(
			'solution_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
        );	
		$this->add_control(
			'solution_sdesc',
			[
				'label' => __('Section Short Discription', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
        );
		/*service two section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'solution_img',
			[
				'label' => __('Solution  Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'solution_btitle',
			[
				'label' => __('Solution  Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'solution_bcontent',
			[
				'label' => __('Solution  Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
        );
		$this->add_control(
			'solution_groups',
			[
				'label' => __( 'Solution Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);


		//style two content
		$this->add_control(
			'solution2_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
        );	
		$this->add_control(
			'solution2_sdesc',
			[
				'label' => __('Section Short Discription', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
        );
		/*service two section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'solution2_img',
			[
				'label' => __('Solution  Image', 'lector'),
				'type' => \Elementor\Controls_Manager::ICON,
			]
        );
        $repeater->add_control(
			'solution2_btitle',
			[
				'label' => __('Solution  Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'solution2_bcontent',
			[
				'label' => __('Solution  Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
        );
        $repeater->add_control(
			'solution2_bottomtxt',
			[
				'label' => __('Solution Bottom Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'solution2_url',
			[
				'label' => __('Solution Button Link', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
		$this->add_control(
			'solution2_groups',
			[
				'label' => __( 'Solution Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		
		$this->add_control(
			'solution2_bottombtn',
			[
				'label' => __('Solution Bottom Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$solution_groups = $this->get_settings('solution_groups');
		$solution2_groups = $this->get_settings('solution2_groups');
	?>
	<!-- services style-2 section start here -->
	<?php 
	if($settings['choose_service'] == 'style-one'):	
	?>
	<section class="services style-2 padding-tb pb-sm-0">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['solution_title'])): ?>
					<h2><?php echo esc_html($settings['solution_title']); ?></h2>
				<?php endif; ?>
				<?php if(!empty($settings['solution_sdesc'])): ?>
					<p><?php echo esc_html($settings['solution_sdesc']); ?></p>
				<?php endif; ?>
			</div>
			<div class="section-wrapper">
				<?php
				if(!empty($solution_groups)):
				 foreach($solution_groups as $solution_group): 
				?>
				<div class="post-item">
					<div class="post-item-inner">
						<div class="post-thumb">
							<?php if(!empty($solution_group['solution_img']['url'])): ?>
								<img src="<?php echo wp_kses_post($solution_group['solution_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
							<?php endif; ?>
						</div>
						<div class="post-content">
							<?php if(!empty($solution_group['solution_btitle'])): ?>
								<h5><?php echo esc_html($solution_group['solution_btitle']); ?></h5>
							<?php endif; ?>
							<?php if(!empty($solution_group['solution_bcontent'])): ?>
								<p><?php echo esc_html($solution_group['solution_bcontent']); ?></p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php
			 endforeach;
			endif;
			?>
			</div>
		</div>
	</section>
	<?php
	elseif($settings['choose_service'] == 'style-two'): 
	?>
	<section class="services style-3 padding-tb">
		<div class="container">
			<div class="row padding-x">
				<div class="section-header">
					<?php if(!empty($settings['solution2_title'])): ?>
						<h2><?php echo esc_html($settings['solution2_title']); ?></h2>
					<?php endif; ?>
					<?php if(!empty($settings['solution2_sdesc'])): ?>
						<p><?php echo esc_html($settings['solution2_sdesc']); ?></p>
					<?php endif; ?>
				</div>
				<div class="section-wrapper">
					<?php 
					if(!empty($solution2_groups)):
					foreach($solution2_groups as $solution2_group):
					?>
					<div class="post-item">
						<div class="post-item-inner">
							<div class="post-thumb">
								<div class="service-icon">
									<i class="fas fa-exclamation-triangle"></i>
								</div>
							</div>
							<div class="post-content">
								<?php if(!empty($solution2_group['solution2_btitle'])): ?>
									<h5><?php echo esc_html($solution2_group['solution2_btitle']); ?></h5>
								<?php endif; ?>
								<?php if(!empty($solution2_group['solution2_bcontent'])): ?>
									<p><?php echo esc_html($solution2_group['solution2_bcontent']); ?></p>
								<?php endif; ?>
								<?php if(!empty($solution2_group['solution2_bottomtxt'])): ?>
									<span><?php echo esc_html($solution2_group['solution2_bottomtxt']); ?></span>
								<?php endif; ?>
								<?php if(!empty($solution2_group['solution2_url']['url'])): ?>
									<a href="<?php echo esc_url($solution2_group['solution2_url']['url']); ?>" class="service-flaticon flaticon-next"></a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php
				 endforeach;
				endif;
				?>
				</div>
				<div class="text-center">
					<a href="<?php if(!empty($settings['solution2_bottombtn'])): echo esc_url($settings['solution2_bottombtn']); endif; ?>" class="btn"><?php esc_html_e('View All Services', 'lector'); ?></a>
				</div>
			</div>
		</div>
	</section>
	<?php 
	endif;
	?>
	<!-- services style-2 section ending here -->
	<?php
		
	}


}





