<?php
class Lector_Counter_Up_Testimonial_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "counterup_testimonial";
	}

	public function get_title() {
		return __( "CounterUp & Testimonial", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'CounterUp & Testimonial Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Section Background Image', 'lector' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .achievement',
			]
		);
        $this->add_control(
			'section_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
        $this->add_control(
			'section_desc',
			[
				'label' => __('Section Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);

		/*counter up section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'counter_number',
			[
				'label' => __('Counter Number', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'counter_symble',
			[
				'label' => __('Counter Symble', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'counter_heading',
			[
				'label' => __('Counter Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'counter_groups',
			[
				'label' => __( 'Counter Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);


		/*testimonial section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'testimonial',
			[
				'label' => __('Testimonial Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'testi_title',
			[
				'label' => __('Testimonial Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'testi_desc',
			[
				'label' => __('Testimonial Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
		$this->add_control(
			'testi_groups',
			[
				'label' => __( 'Testimonial Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

	
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$counter_groups = $this->get_settings('counter_groups');
		$testi_groups = $this->get_settings('testi_groups');
	?>
	 <!-- achievement section start here -->
	<section class="achievement style-2 padding-tb">
		<div class="container">
			<div class="row padding-x">
				<div class="counter-up">
					<div class="section-header">
						<?php if(!empty($settings['section_title'])): ?>
						<h2><?php echo esc_html($settings['section_title']); ?></h2>
						<?php endif;  ?>
						<?php if(!empty($settings['section_desc'])): ?>
						<p><?php echo esc_html($settings['section_desc']); ?></p>
						<?php endif;  ?>
					</div>
					<div class="section-wrapper">
						<div class="counter-area">
							<?php
							if(!empty($counter_groups)):
							foreach ($counter_groups as $counter_group):
							?>
							<div class="content-item">
								<?php if(!empty($counter_group['counter_number'])): ?>
								<span class="counter"><?php echo esc_html($counter_group['counter_number']); ?></span>
								<?php endif;  ?>
								<?php if(!empty($counter_group['counter_symble'])): ?>
								<span class="count-view"><?php echo esc_html($counter_group['counter_symble']); ?></span> 
								<?php endif;  ?>
								<?php if(!empty($counter_group['counter_heading'])): ?>
								<p><?php echo esc_html($counter_group['counter_heading']); ?></p>
								<?php endif;  ?>
							</div>
							<?php
							endforeach;
							endif;
							?>
						</div>
					</div>
				</div>
				<div class="achive-area">
					<div class="achive-slider">
						<div class="swiper-wrapper">
							<?php
							if(!empty($testi_groups)):
							foreach ($testi_groups as $testi_group):
							?>
							<div class="swiper-slide">
								<div class="post-item">
									<div class="post-item-inner">
										<div class="post-thumb">
											<?php if(!empty($testi_group['testimonial']['url'])): ?>
											<img src="<?php echo wp_kses_post($testi_group['testimonial']['url']); ?>" alt="<?php bloginfo('name'); ?>">
											<?php endif; ?>
										</div>
										<div class="post-content">
											<?php if(!empty($testi_group['testi_title'])): ?>
											<h4><?php echo esc_html($testi_group['testi_title']); ?></h4>
											<?php endif; ?>
											<?php if(!empty($testi_group['testi_desc'])): ?>
											<p><?php echo esc_html($testi_group['testi_desc']); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							endforeach;
							endif;
							?>
						</div>
						<div class="achive-pagination"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- achievement section ending here -->
	<?php
		
	}


}





