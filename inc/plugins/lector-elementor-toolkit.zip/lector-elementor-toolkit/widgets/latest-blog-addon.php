<?php
class Lector_Latest_Blog_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_blog";
	}

	public function get_title() {
		return __( "Latest Blog", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Blog Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'blog_title',
			[
				'label' => __('Blog Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'blog_sdesc',
			[
				'label' => __('Blog Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'blog_count',
			[
				'label' => __('Blog Count', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
			
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- blog section start here -->
	<section class="blog-section padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['blog_title'])): ?>
					<h2><?php echo esc_html($settings['blog_title']); ?></h2>
				<?php endif; ?>
				<?php if(!empty($settings['blog_sdesc'])): ?>
					<p><?php echo esc_html($settings['blog_sdesc']); ?></p>
				<?php endif; ?>
			</div>
			<div class="section-wrapper">
				<div class="blog-slider">
					<div class="swiper-wrapper">
						<?php 
							$query = new Wp_query(array(
								'post_type' => 'post',
								'posts_per_page' => esc_attr($settings['blog_count']),
								'order_by' => 'title',
								'ignore_sticky_posts' => 1
							));

						if ( $query->have_posts() ) :
						while($query->have_posts()): 
						 	$query->the_post(); 
						?>
				      	<div class="swiper-slide">
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-thumb">
										<a href="<?php the_permalink(); ?>">
											<?php
									            if ( has_post_thumbnail() ): 
									                the_post_thumbnail(); 
									            endif; 
									        ?>
								        </a>
									</div>
									<div class="post-content">
										<div class="content-area">
											<h5>
												<a href="<?php the_permalink(); ?>">
													<?php
														$lector_title = get_the_title();
														$lector_short_title = wp_trim_words($lector_title, 6, ' ');
														echo esc_html($lector_short_title);
													?>
												</a>
											</h5>
											<div class="meta-post">
			                                    <span class="by">
			                                    	<a class="date" href="<?php the_permalink(); ?>"><?php echo get_the_date('F j, Y'); ?></a>
			                                    	<a class="name" href="<?php the_permalink(); ?>"><?php echo get_the_author_meta( 'display_name'); ?></a>
			                                    </span>
			                                </div>
			                                <?php 
												$lector_xcerpt = get_the_excerpt();
												$shortexcerpt = wp_trim_words($lector_xcerpt, $num_words = 10, ' ');
												echo esc_html($shortexcerpt);
											?>
										</div>
										<div class="social-area">
											<div class="admin">
												<a href="<?php echo esc_url(get_the_author_link()); ?>">
													<?php echo get_avatar( get_the_author_meta( 'ID' ), 150 ); ?>
												</a>
											</div>
										
											<?php
											 if(function_exists('lector_social_share')): 
											?>
												<div class="social-media">
													<span><?php esc_html_e('Share This', 'lector'); ?></span>
													<ul>
														<?php 
															echo lector_social_share();
														?> 
													</ul>
												</div>
											<?php
											endif; 
											?>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
						 endwhile; 
						endif;
						 wp_reset_query();
						?>
					</div>
					<div class="blog-pagination"></div>
				</div>
			</div>
		</div>
	</section>
	<!-- blog section ending here -->
	<?php
		
	}


}





