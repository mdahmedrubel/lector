<?php
class Lector_Home_One_Client_Video_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_client_video";
	}

	public function get_title() {
		return __( "Client Videos", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Videos Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		$this->add_control(
			'video_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		/*videos section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'video_bg',
			[
				'label' => __('Video Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'video_id',
			[
				'label' => __('Video ID', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => 'Only video id allowed',
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'play_icon',
			[
				'label' => __('Video Play Icon Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
		$this->add_control(
			'videos_groups',
			[
				'label' => __( 'Videos Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Section Background', 'lector' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .video.style-2',
			]
		);
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$videos_groups = $this->get_settings('videos_groups');
	?>
	<!-- vedio section start here -->
	<section class="video style-2 padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['video_title'])): ?>
					<h2><?php echo esc_html($settings['video_title']); ?></h2>
				<?php endif; ?>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($videos_groups)):
					$count = 0;
					foreach($videos_groups as $videos_group):
					$count++;
					?>
					<div class="post-item">
						<div class="post-item-inner">
							<div class="post-thumb">
								<?php if(!empty($videos_group['video_bg']['url'])): ?>
									<img src="<?php echo wp_kses_post($videos_group['video_bg']['url']); ?>" alt="<?php bloginfo('name'); ?>">
								<?php endif; ?>
								<a href="https://www.youtube.com/embed/<?php if(!empty($videos_group['video_id'])): echo esc_html($videos_group['video_id']); endif; ?>" data-rel="lightcase" title="<?php esc_html_e('Watch Now', 'lector'); ?>" class="video-icon">

									<?php if(!empty($videos_group['play_icon']['url'])): ?>
										<img src="<?php echo wp_kses_post($videos_group['play_icon']['url']); ?>" alt="<?php bloginfo('name'); ?>">
									<?php endif; ?>
								</a>
							</div>
						</div>
					</div>
					<?php 
					if($count==4){
						break;
					}
					endforeach;
				endif;
				?>
			</div>
		</div>
	</section>
	<!-- vedio section ending here -->
	<?php
		
	}


}





