<?php
class Home_One_How_We_Work_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_how_word";
	}

	public function get_title() {
		return __( "How We Work", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'How We Work Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		$this->add_control(
			'work_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );	
		$this->add_control(
			'work_sdesc',
			[
				'label' => __('Section Short Discription', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
		/*how we work section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'work_img',
			[
				'label' => __('How We Work Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'work_txt',
			[
				'label' => __('How We Work Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'work_groups',
			[
				'label' => __( 'Progress Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$work_groups = $this->get_settings('work_groups');
	?>
	<!-- our progress section start here -->
	<section class="progress style-2 padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['work_title'])): ?>
					<h2><?php echo esc_html($settings['work_title']); ?></h2>
				<?php endif; ?>
				<?php if(!empty($settings['work_sdesc'])): ?>
					<p><?php echo esc_html($settings['work_sdesc']); ?></p>
				<?php endif; ?>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($work_groups)):
				foreach($work_groups as $work_group): 
				?>
				<div class="post-item">
					<div class="post-item-inner">
						<div class="post-thumb">
							<?php if(!empty($work_group['work_img']['url'])): ?>
								<img src="<?php echo wp_kses_post($work_group['work_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
							<?php endif; ?>
						</div>
						<?php if(!empty($work_group['work_txt'])): ?>
							<div class="post-content">
								<span><?php echo esc_html($work_group['work_txt']); ?></span>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php
			 endforeach;
			endif;
			?>
			</div>
		</div>
	</section>
	<!-- our progress section ending here -->
	<?php
		
	}


}





