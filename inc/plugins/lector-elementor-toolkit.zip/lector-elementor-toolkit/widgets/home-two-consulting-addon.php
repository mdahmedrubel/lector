<?php
class Lector_Consulting_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_consulting";
	}

	public function get_title() {
		return __( "Consulting", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Consulting Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'consulting_img',
			[
				'label' => __('Consulting Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		); 
		$this->add_control(
			'consulting_title',
			[
				'label' => __('Consulting Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'consulting_sdesc',
			[
				'label' => __('Consulting Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
			
		/*sponsore section*/
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'consult',
			[
				'label' => __('Consulting Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'consult_groups',
			[
				'label' => __( 'Consulting Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->add_control(
			'consult_btn',
			[
				'label' => __('Consulting Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'consult_url',
			[
				'label' => __('Consulting Button Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$consult_groups = $this->get_settings('consult_groups');
	?>
	<!-- consulting section start here -->
	<section class="consulting padding-tb">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-12">
					<div class="post-thumb">
						<div class="cp-thumb">
							<?php if(!empty($settings['consulting_img']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['consulting_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-12">
					<div class="post-content">
							<?php if(!empty($settings['consulting_title'])): ?>
								<h2><?php echo esc_html($settings['consulting_title']); ?></h2>
							<?php endif; ?>
							<?php if(!empty($settings['consulting_sdesc'])): ?>
								<p><?php echo esc_html($settings['consulting_sdesc']); ?></p>
							<?php endif; ?>
						<ul>
							<?php
							if(!empty($consult_groups)):
							 foreach($consult_groups as $consult_group): 
							?>
							<li>
								<i class="fas fa-check"></i>
								<?php echo esc_html($consult_group['consult']); ?>
							</li>
							<?php
							 endforeach;
							endif;
							?>
						</ul>
						<?php if(!empty($settings['consult_btn'])): ?>
						<a href="<?php echo esc_url($settings['consult_url']['url']); ?>" class="btn"><?php echo esc_html($settings['consult_btn']); ?></a>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- consulting section ending here -->
	<?php
		
	}


}





