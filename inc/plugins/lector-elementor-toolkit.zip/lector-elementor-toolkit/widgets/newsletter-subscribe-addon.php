<?php
class Lector_Newsletter_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_newsletter";
	}

	public function get_title() {
		return __( "NewsLetter", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'NewsLetter Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'newsletter_title',
			[
				'label' => __('NewsLetter Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'newsletter_stitle',
			[
				'label' => __('NewsLetter Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'newsletter_shortcode',
			[
				'label' => __('NewsLetter ShortCode', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
	
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- newslettar section satrt here -->
    <section class="news-letter padding-tb">
		<div class="container">
			<div class="section-header">
				<?php if(!empty($settings['newsletter_title'])): ?>
				<h2><?php echo esc_html($settings['newsletter_title']); ?></h2>
				<?php endif;  ?>
				<?php if(!empty($settings['newsletter_stitle'])): ?>
				<p><?php echo esc_html($settings['newsletter_stitle']); ?></p>
				<?php endif;  ?>
			</div>
			<div class="row">
				<div class="col-lg-8 offset-lg-2">
					<div class="section-wrapper">
						<div class="recent-news">
							<div class="newsltr">
								<?php
								if(!empty($settings['newsletter_shortcode'])):
								 echo do_shortcode($settings['newsletter_shortcode']);
								endif; 
								?> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- newslettar section ending here -->
	<?php
		
	}


}





