<?php
class Home_One_Progress_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_progress";
	}

	public function get_title() {
		return __( "Progress", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Our Progress Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);	
		$this->add_control(
			'Progress_title',
			[
				'label' => __('Section Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );	
		$this->add_control(
			'progress_sdesc',
			[
				'label' => __('Section Short Discription', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
		/*progress section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'progress_list',
			[
				'label' => __('Progress List Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'progress_groups',
			[
				'label' => __( 'Progress Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		$this->add_control(
			'progress_btn',
			[
				'label' => __('Section Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $this->add_control(
			'progress_btn_url',
			[
				'label' => __('Section Butotn Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $this->add_control(
			'progress_img',
			[
				'label' => __('Progress Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$progress_groups = $this->get_settings('progress_groups');
	?>
	<!-- our progress section start here -->
	<section class="progress padding-tb">
		<div class="container">
			<div class="section-wrapper">
				<div class="post-item">
					<div class="post-item-inner">
						<div class="post-thumb d-none d-md-block">
							<?php if(!empty($settings['progress_img']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['progress_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
							<?php endif; ?>
						</div>
						<div class="post-content">
							<?php if(!empty($settings['Progress_title'])): ?>
								<h2><?php echo esc_html($settings['Progress_title']); ?></h2>
							<?php endif; ?>
							<?php if(!empty($settings['progress_sdesc'])): ?>
								<p><?php echo esc_html($settings['progress_sdesc']); ?></p>
							<?php endif; ?>
							<ul>
								<?php
								if(!empty($progress_groups)):
								 foreach($progress_groups as $progress_group): 
								?>
								<?php if(!empty($progress_group['progress_list'])): ?>
									<li><?php echo esc_html($progress_group['progress_list']); ?></li>
								<?php endif; ?>
								<?php
								 endforeach; 
								endif;
								?>
							</ul>
							<?php if(!empty($settings['progress_btn'])): ?>
								<a href="<?php echo esc_url($settings['progress_btn_url']); ?>" class="btn"><?php echo esc_html($settings['progress_btn']); ?>
								</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- our progress section ending here -->
	<?php
		
	}


}





