<?php
class Custom_Post_Service_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_service_custom";
	}

	public function get_title() {
		return __( "Services Main", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Services Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'scount',
			[
				'label' => __('Services Count', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- Service  section ending here -->
    <section class="services style-4 padding-tb">
        <div class="container">
            <div class="section-wrapper">
                <div class="row justify-content-center">
                	<?php 
                	$service_q = new WP_Query(array(
                		'post_type' => 'service',
                		'posts_per_page' => esc_attr($settings['scount']),
                		'orderby' => 'rand',
                		'post_status' => 'publish',
                	));

                	if($service_q->have_posts()):
                	while ($service_q->have_posts()):
                		$service_q->the_post();
                		$service_m = get_post_meta(get_the_ID(), 'service_meta', true);

                		if ( isset($service_m['service_icon']['id'])) {
                		$post_simg = wp_get_attachment_image_src($service_m['service_icon']['id'], 'large');
                	}
                	?>
                    <div class="post-item">
                        <div class="post-inner">
                            <div class="post-thumb">
                            	<?php 
                            	$post_img = get_the_post_thumbnail_url();
                            	?>
                                <a href="<?php the_permalink(); ?>">
                                	<img src="<?php echo esc_url($post_img); ?>" alt="<?php bloginfo('name'); ?>">
                                </a>
                            </div>
                        </div>
                        <div class="post-inner">
                            <div class="post-content">
                                <div class="icon-thumb">
                                    <img src="<?php echo esc_url($post_simg[0]); ?>" alt="<?php bloginfo('name'); ?>">
                                </div>
                                <div class="content">
                                    <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                    <p>
                                    	<?php 
											$service_xcerpt = get_the_excerpt();
											$shortexcerpt = wp_trim_words($service_xcerpt, $num_words = 7, ' ');
											echo esc_html($shortexcerpt);
										?>
                                    </p>
                                    <a href="<?php the_permalink(); ?>"><?php esc_html_e('View Service Details', 'lector'); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                endwhile;
                endif; 
                ?>
                </div>
            </div>
        </div>
    </section>
	<?php
		
	}


}





