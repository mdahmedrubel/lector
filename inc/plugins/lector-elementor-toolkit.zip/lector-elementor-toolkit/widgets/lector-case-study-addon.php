<?php
class Lector_Case_Study_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_case_st";
	}

	public function get_title() {
		return __( "Main Case Study", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Case Study Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- case section section start here -->
    <section class="case-study style-3 padding-tb">
        <div class="container">
            <ul class="post-nav">
               <li data-filter="*" class="active"><?php esc_html_e('All', 'lector'); ?></li>
                <?php 
					$etab_terms = get_terms( 'case', array(
				 	'hide_empty' => true,
					));

					$etab_count = 0;
					if(!empty($etab_terms)):
					foreach($etab_terms as $etab_term):
					$etab_count++;
					?>
	                <li data-filter=".<?php echo esc_attr($etab_term->slug); ?>">
	                	<?php echo esc_html($etab_term->name); ?>
	                </li>
	                <?php 
					if($etab_count == 5){
						break;
					}
					endforeach; 
					endif;
				?>
            </ul>
            <div class="section-wrapper">
        		<?php 
	        		$etab_terms = get_terms( 'case', array(
				 	'hide_empty' => true,
					));
					if(!empty($etab_terms)):
					foreach($etab_terms as $etab_term):
								
					$case_q = new WP_Query(array(
						'post_type' => 'case-study',
						'post_status' => 'publish',
						'posts_per_page' =>-1,
						'order' => 'DESC',
						'tax_query' =>array(
							array(
								'taxonomy' => 'case',
								'field' => 'slug',
								'terms' => $etab_term->slug,
								)
							)
						)
					);
					if ($case_q->have_posts()) :
					while($case_q->have_posts()): $case_q->the_post(); 
					$case_smeta = get_post_meta(get_the_ID(), 'case_meta', true);
				?>
                <div class="post-item <?php echo esc_attr($etab_term->slug); ?>">
                    <div class="post-inner">
                        <div class="post-thumb">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <div class="post-content">
                        	<?php if(!empty($case_smeta['sub_title'])): ?>
                            	<p><?php echo esc_html($case_smeta['sub_title']); ?></p>
                        	<?php endif; ?>
                            <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                        </div>
                    </div>
                </div>
                <?php 
					endwhile; 
					endif;
					wp_reset_query();
		
					endforeach;
					endif;
				?>
            </div>
        </div>
    </section>
    <!-- case section section ending here -->
	<?php
		
	}


}





