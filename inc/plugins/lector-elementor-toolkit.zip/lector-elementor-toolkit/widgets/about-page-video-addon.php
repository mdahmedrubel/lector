<?php
class Lector_About_video_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_about_video";
	}

	public function get_title() {
		return __( "Lector Video", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Video Section Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_style',[
				'label' => __( 'Select video Style', 'lector' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-one',
				'label_block' => true,
				'options' => [
					'style-one'  => __( 'Video Style One', 'lector' ),
					'style-two'  => __( 'Video Style Two', 'lector' ),
				],
			]
        );
        $this->add_control(
			'video_image',
			[
				'label' => __('About Video Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_text',
			[
				'label' => __('About Video Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_url',
			[
				'label' => __('About Video Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_right_stitle',
			[
				'label' => __('About Video Right Sub Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_right_title',
			[
				'label' => __('About Video Right Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_right_desc',
			[
				'label' => __('About Video Right Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_btn_txt',
			[
				'label' => __('About Video Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
	    $this->add_control(
			'video_btn_url',
			[
				'label' => __('About Video Button Text', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);

		//video style two content
		$this->add_control(
			'video2_image',
			[
				'label' => __('Video Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->add_control(
			'video2_url',
			[
				'label' => __('Video Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_style',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- about section start here -->
	<?php 
	if($settings['choose_style'] == 'style-one'):	
	?>
    <section class="about padding-tb">
        <div class="container">
            <div class="row padding-x">
                <div class="section-wrapper">
                    <div class="post-thumb">
                    	<?php if(!empty($settings['video_image']['url'])): ?>
                        <img src="<?php echo wp_kses_post($settings['video_image']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                    	<?php endif; ?>
                        <div class="about-video">
                        	<?php if(!empty($settings['video_text'])): ?>
                            <span><?php echo esc_html($settings['video_text']); ?></span>
                            <?php endif; ?>
                            <?php if(!empty($settings['video_url'])): ?>
                            <a href="<?php echo esc_url($settings['video_url']['url']); ?>" data-rel="lightcase" title="<?php esc_html_e('Watch Now', 'lector'); ?>" class="av-icon">
                                <div class="pulse1"></div>
                                <i class="fas fa-play"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="post-content">
                    	 <?php if(!empty($settings['video_right_stitle'])): ?>
                        <h5><?php echo esc_html($settings['video_right_stitle']); ?></h5>
                        <?php endif; ?>
                         <?php if(!empty($settings['video_right_title'])): ?>
                        <h2><?php echo esc_html($settings['video_right_title']); ?></h2>
                        <?php endif; ?>
                         <?php if(!empty($settings['video_right_desc'])): ?>
                        <p><?php echo esc_html($settings['video_right_desc']); ?></p>
                        <?php endif; ?>
                         <?php if(!empty($settings['video_btn_txt'])): ?>
                        <a href="<?php echo esc_url($settings['video_btn_url']['url']); ?>" class="btn"><?php echo esc_html($settings['video_btn_txt']); ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
	elseif($settings['choose_style'] == 'style-two'): 
	?>
	<div class="video">
		<div class="container">
			<div class="section-wrapper">
				<div class="video-post">
					<div class="video-thumb">
						<?php if(!empty($settings['video2_image']['url'])): ?>
                        	<img src="<?php echo wp_kses_post($settings['video2_image']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                    	<?php endif; ?>
						<a href="<?php if(!empty($settings['video2_url']['url'])): echo esc_url($settings['video2_url']['url']); endif; ?>" data-rel="lightcase" title="<?php esc_html_e('Watch Now', 'lector'); ?>" class="video-icon"><div class="pulse1"></div><i class="fas fa-play"></i>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php 
	endif;
	 ?>
    <!-- about section ending here -->
	<?php
		
	}


}





