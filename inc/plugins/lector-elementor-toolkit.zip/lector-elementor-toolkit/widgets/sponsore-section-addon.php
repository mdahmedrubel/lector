<?php
class Lector_Sponsore_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_sponsore";
	}

	public function get_title() {
		return __( "Sponsore", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Sponsore Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'sponsore_title',
			[
				'label' => __('Sponsore Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		); 
		$this->add_control(
			'sponsore_stitle',
			[
				'label' => __('Sponsore Short Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
			
		/*sponsore section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'sponsore',
			[
				'label' => __('Sponsore Image', 'lector'),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        $repeater->add_control(
			'sponsore_url',
			[
				'label' => __('Sponsore Image Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
		$this->add_control(
			'sponsor_groups',
			[
				'label' => __( 'Sponsore Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$sponsor_groups = $this->get_settings('sponsor_groups');
	?>
	<!-- sponsor section start here  -->
	<section class="sponsor style-3 padding-tb">
        <div class="container">
            <div class="section-header">
                <?php if(!empty($settings['sponsore_title'])): ?>
				<h2><?php echo esc_html($settings['sponsore_title']); ?></h2>
				<?php endif;  ?>
                <?php if(!empty($settings['sponsore_stitle'])): ?>
				<p><?php echo esc_html($settings['sponsore_stitle']); ?></p>
				<?php endif;  ?>
            </div>
            <div class="section-wrapper d-flex flex-wrap justify-content-center">
            	<?php
				if(!empty($sponsor_groups)):
				foreach ($sponsor_groups as $sponsor_group):
				?>
                <div class="post-thumb">
                	<?php if(!empty($sponsor_group['sponsore']['url'])): ?>
                    <a href="<?php echo esc_url($sponsor_group['sponsore_url']['url']); ?>">
                    	<img src="<?php echo wp_kses_post($sponsor_group['sponsore']['url']); ?>" alt="<?php bloginfo('name'); ?>">
                    </a>
                    <?php endif;  ?>
                </div>
                <?php
				endforeach;
				endif;
				?>
            </div>
        </div>
    </section>
    <!-- sponsor section ending here -->
	<?php
		
	}


}





