<?php
class Lector_Advisor_Testimonial_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "lector_advi_testi";
	}

	public function get_title() {
		return __( "Advisor Testimonial", 'lector' );
	}

	public function get_icon() {
		return 'fa fa-image';
	}

	public function get_categories() {
		return array( 'lector');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Testimonial Settings', 'lector' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_tessti',[
				'label' => __( 'Select Testimonial Style', 'lector' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-one',
				'label_block' => true,
				'options' => [
					'style-one'  => __( 'Testimonial Style 1', 'lector' ),
					'style-two'  => __( 'Testimonial Style 2', 'lector' ),
				],
			]
        );
			
		/*advisor section*/
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'advisor_testi',
			[
				'label' => __('Advisor Testimonial Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'advisor_ttitle',
			[
				'label' => __('Advisor Testimonial Position', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'advisor_tdesc',
			[
				'label' => __('Advisor Testimonial Description', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'fb_url',
			[
				'label' => __('Advisor Testimonial Facebook Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'tw_url',
			[
				'label' => __('Advisor Testimonial Twitter Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'ld_url',
			[
				'label' => __('Advisor Testimonial Linkedin Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
        $repeater->add_control(
			'goo_url',
			[
				'label' => __('Advisor Testimonial G+ Url', 'lector'),
				'type' => \Elementor\Controls_Manager::URL,
			]
        );
		$this->add_control(
			'adtesti_groups',
			[
				'label' => __( 'Sponsore Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_tessti',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);

		$this->add_control(
			'advisor_txt',
			[
				'label' => __('Advisor Text', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_tessti',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
        );


        // style two settings
        $this->add_control(
			'testi2_title',
			[
				'label' => __('Testimonial Title', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_tessti',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
        );
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'testi2_content',
			[
				'label' => __('Testimonial Content', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'testi2_name',
			[
				'label' => __('Testimonial Name', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'testi2_name_url',
			[
				'label' => __('Testimonial Name Url', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
        $repeater->add_control(
			'testi2_position',
			[
				'label' => __('Testimonial Position', 'lector'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
        );
		$this->add_control(
			'testi2_groups',
			[
				'label' => __( 'Testimonial Content', 'lector' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_tessti',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);

		
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$adtesti_groups = $this->get_settings('adtesti_groups');
		$testi2_groups = $this->get_settings('testi2_groups');
	?>
	<!-- advisors section start here -->
	<?php 
	if($settings['choose_tessti'] == 'style-one'):	
	?>
	<section class="advisors style-2 padding-tb">
		<div class="container">
			<div class="row padding-x">
				<div class="section-wrapper">
					<div class="advisors-left">
						<div class="advisor-port-slider">
							<div class="swiper-wrapper">
								<?php 
								if(!empty($adtesti_groups)):
								foreach($adtesti_groups as $solution2_group):
								?>
								<div class="swiper-slide">

									<div class="advisor-top">
										<div class="section-title">
											<?php if(!empty($solution2_group['advisor_testi'])): ?>
												<h2><?php echo esc_html($solution2_group['advisor_testi']); ?></h2>
											<?php endif; ?>
											<?php if(!empty($solution2_group['advisor_ttitle'])): ?>
												<p><?php echo esc_html($solution2_group['advisor_ttitle']); ?></p>
											<?php endif; ?>
											<?php if(!empty($solution2_group['advisor_tdesc'])): ?>
												<p><?php echo esc_html($solution2_group['advisor_tdesc']); ?></p>
											<?php endif; ?>
											<ul class="social-link-list">
												<?php if(!empty($solution2_group['fb_url']['url'])): ?>
													<li>
														<a href="<?php echo esc_url($solution2_group['fb_url']['url']); ?>" class="facebook"><i class=" fab fa-facebook-f"></i></a>
													</li>
												<?php endif; ?>
												<?php if(!empty($solution2_group['tw_url']['url'])): ?>
													<li>
														<a href="<?php echo esc_url($solution2_group['tw_url']['url']); ?>" class="twitter-sm"><i class="fab fa-twitter"></i></a>
													</li>
												<?php endif; ?>
												<?php if(!empty($solution2_group['ld_url']['url'])): ?>
													<li>
														<a href="<?php echo esc_url($solution2_group['ld_url']['url']); ?>" class="linkedin"><i class="fab fa-linkedin-in"></i></a>
													</li>
												<?php endif; ?>
												<?php if(!empty($solution2_group['goo_url']['url'])): ?>
													<li>
														<a href="<?php echo esc_url($solution2_group['goo_url']['url']); ?>" class="google"><i class="fab fa-google-plus-g"></i></a>
													</li>
												<?php endif; ?>
											</ul>
										</div>
									</div>
								</div>
								<?php
								 endforeach;
								endif;
								?>

							</div>
						</div>
						<div class="advisor-navigation">
							<div class="advisor-port-next flaticon-back"></div>
							<div class="advisor-port-prev flaticon-next"></div>
						</div>
					</div>
					<div class="advisors-right">
						<?php if(!empty($settings['advisor_txt'])): ?>
						<div class="advisors-title">
							<span><?php echo esc_html($settings['advisor_txt']); ?></span>
						</div>
						<?php endif; ?>
						<div class="advisor-port-pagination"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
	elseif($settings['choose_tessti'] == 'style-two'): 
	?>
	<section class="testimonial style-3 padding-tb">
		<div class="container">
			<div class="section-wrapper">
				<div class="testimonial-slider">
					<svg><circle class="animation-two" r="300" cx="300" cy="300"></circle></svg>
					<?php if(!empty($settings['testi2_title'])): ?>
						<h6><?php echo esc_html($settings['testi2_title']); ?></h6>
					<?php endif; ?>
					<div class="section-wrapper testi-slider">
						<div class="swiper-wrapper">
							<?php 
							if(!empty($testi2_groups)):
							foreach($testi2_groups as $testi2_group):
							?>
							<div class="swiper-slide">
								<div class="post-item">
									<div class="post-inner">
										<?php if(!empty($testi2_group['testi2_content'])): ?>
										<p><?php echo esc_html($testi2_group['testi2_content']); ?></p>
										<?php endif; ?>
										<?php if(!empty($testi2_group['testi2_name'])): ?>
										<h5><a href="<?php echo esc_url($testi2_group['testi2_name_url']); ?>"><?php echo esc_html($testi2_group['testi2_name']); ?></a></h5>
										<?php endif; ?>
										<?php if(!empty($testi2_group['testi2_position'])): ?>
										<span><?php echo esc_html($testi2_group['testi2_position']); ?></span>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<?php
							 endforeach;
							endif;
							?>

						</div>
						<div class="testi-navigation">
							<div class="testi-next flaticon-back"></div>
							<div class="testi-prev flaticon-next"></div>
						</div>
					</div>
					<div class="testi-pagination">
						<div><span></span></div>
						<div><span></span></div>
						<div><span></span></div>
						<div><span></span></div>
						<div><span></span></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php 
	endif;
	?>
	<!-- advisors section ending here -->
	<?php
		
	}


}





