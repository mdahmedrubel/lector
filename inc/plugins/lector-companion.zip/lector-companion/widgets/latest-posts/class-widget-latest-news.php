<?php
/**
 * Latest Posts widget.
 */
class lector_latest_blog_widget extends WP_Widget {
    /**
     * Register widget with WordPress.
     */
    function __construct() {
        parent::__construct(
            'lector_latest_news_widget', // Base ID
            esc_html__( 'Lector :: Latest Posts', 'lector' ), // Name
            array( 'description' => esc_html__( 'Lector latest posts widget', 'lector' ), ) // Args
        );
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Your Title', 'lector' );
        $count = ! empty($instance['count']) ? $instance['count'] : esc_html__('Add Post Count','lector');
        ?>
        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'lector' ); ?></label> 
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Posts Limit:', 'lector' ); ?></label> 
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="text" value="<?php echo esc_attr( $count ); ?>">
        </p>
        <?php 
    }
    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo wp_kses_post($args['before_widget']);

        ?>
        <div class="widget widget-post">
            <h4><?php if(!empty($instance['title'])): echo esc_html($instance['title']); endif; ?></h4>
            <ul>
                <?php 
                    $latest_post = new WP_Query(array(
                        'post_type' => 'post',
                        'posts_per_page' => $instance['count'],
                        'ignore_sticky_posts' => 1
                    ));
                    if($latest_post->have_posts()) : while($latest_post->have_posts()) : $latest_post->the_post();
                ?>
                <li>
                    <h6>
                        <a href="<?php the_permalink();?>"><h6><?php echo wp_trim_words( get_the_title(), 7, '') ; ?></a>
                    </h6>
                    <p><?php echo get_the_date('F j, Y'); ?></p>
                </li>
                <?php 
                    endwhile;
                    wp_reset_query();
                    endif;
                ?>
            </ul>
        </div>
    <?php 
    echo wp_kses_post($args['after_widget']);
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = $new_instance['title'];
        $instance['count'] = $new_instance['count'];

        return $instance;
    }

} 
/**
 * Register Sidebar Widget
 */
if ( ! function_exists( 'lector_latest_news_widget' ) ) {
    function lector_latest_news_widget() {
        register_widget('lector_latest_blog_widget');
    }
    add_action( 'widgets_init', 'lector_latest_news_widget' );
}