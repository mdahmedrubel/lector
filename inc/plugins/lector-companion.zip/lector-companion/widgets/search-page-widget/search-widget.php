<?php 
class Searchpagewidget_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'searchpagewidget_widget',
			esc_html__( 'Lector:: Search page widget', 'lector' ),
			array( 'description' => esc_html__( 'Widget for search page', 'lector' ), ) 
		);
	}

	private $widget_fields = array(
		array(
			'label' => 'Title',
			'id' => 'title_text',
			'default' => 'Need a new search?',
			'type' => 'text',
		),
		array(
			'label' => 'Short Desc',
			'id' => 'shortdesc_textarea',
			'default' => 'If you didn\'t find what you were looking for, try a new search!',
			'type' => 'textarea',
		),
		array(
			'label' => 'Search Here',
			'id' => 'searchhere_text',
			'default' => 'Search',
			'type' => 'text',
		),
	);

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		?>
		<div class="widget-search-title">
			<h4><?php if(!empty($instance['title_text'])): echo esc_html($instance['title_text']); endif; ?></h4>
			<p><?php if(!empty($instance['shortdesc_textarea'])): echo esc_html($instance['shortdesc_textarea']); endif; ?></p>
		</div>

		<div class="widget widget-search mb-0">
			<form role="search" method="get" action="<?php echo home_url( '/' ); ?>" class="search-wrapper">
				<input type="search" name="s" value="<?php echo get_search_query() ?>" placeholder="<?php if(!empty($instance['searchhere_text'])): echo esc_attr($instance['searchhere_text']); endif; ?>">
				<button type="submit"><i class="fas fa-search"></i></button>
			</form>
		</div>
		<?php
		
		echo $args['after_widget'];
	}

	public function field_generator( $instance ) {
		$output = '';
		foreach ( $this->widget_fields as $widget_field ) {
			$default = '';
			if ( isset($widget_field['default']) ) {
				$default = $widget_field['default'];
			}
			$widget_value = ! empty( $instance[$widget_field['id']] ) ? $instance[$widget_field['id']] : esc_html__( $default, 'lector' );
			switch ( $widget_field['type'] ) {
				case 'textarea':
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'lector' ).':</label> ';
					$output .= '<textarea class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" rows="6" cols="6" value="'.esc_attr( $widget_value ).'">'.$widget_value.'</textarea>';
					$output .= '</p>';
					break;
				default:
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'lector' ).':</label> ';
					$output .= '<input class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $widget_value ).'">';
					$output .= '</p>';
			}
		}
		echo $output;
	}

	public function form( $instance ) {
		$this->field_generator( $instance );
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		foreach ( $this->widget_fields as $widget_field ) {
			switch ( $widget_field['type'] ) {
				default:
					$instance[$widget_field['id']] = ( ! empty( $new_instance[$widget_field['id']] ) ) ? strip_tags( $new_instance[$widget_field['id']] ) : '';
			}
		}
		return $instance;
	}
}

if(!function_exists('register_searchpagewidget_widget')){
	function register_searchpagewidget_widget() {
		register_widget( 'Searchpagewidget_Widget' );
	}
	add_action( 'widgets_init', 'register_searchpagewidget_widget' );
}