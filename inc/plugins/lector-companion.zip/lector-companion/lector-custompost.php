<?php 
/*
*This is for showing custom post for the theme
*/

/*Lector service custom post type */
if ( !class_exists('Lector_Service_Custom_Post_Type') ):
	class Lector_Service_Custom_Post_Type {
		public static $post_type = 'service';
		public static $menu_position = 11;
		public static function register() {
			
			// titles
			$labels = array(
				'name'                  => esc_html__('Services',                 'lector'),
				'singular_name'         => esc_html__('Service',            	  'lector'),
				'add_new'               => esc_html__('Add New Service',          'lector'),
				'add_new_item'          => esc_html__('Add New Service',          'lector'),
				'edit_item'             => esc_html__('Edit Service',             'lector'),
				'new_item'              => esc_html__('New Service',              'lector'),
				'view_item'             => esc_html__('View Service',             'lector'),
				'search_items'          => esc_html__('Search Service',           'lector'),
				'not_found'             => esc_html__('No Service found',         'lector'),
				'not_found_in_trash'    => esc_html__('No Service found in trash','lector'),
				'all_items'			    => esc_html__( 'All Service', 			  'lector' ), 
				'featured_image'        => esc_html__( 'Service image', 		  'lector' ),    
			    'set_featured_image'    => esc_html__( 'Set Service image', 	  'lector' ),    
			    'remove_featured_image' => esc_html__( 'Remove Service image', 	  'lector' ), 
			    'use_featured_image'    => esc_html__( 'Use as Service image',    'lector' ),
				'parent_item_colon'     => '',
				'menu_name'             => esc_html__('Services',                 'lector')
			);

// 			// options
			$args = array(
				'labels'                => $labels,
				'public'                => true,
				'publicly_queryable'    => true,
				'show_ui'               => true,
				'show_in_menu'          => true, 
				'query_var'             => true,
				'rewrite'               => array( 'slug' => self::$post_type ),
				'capability_type'       => 'post',
				'has_archive'           => false, 
				'hierarchical'          => false,
				'menu_position'         => self::$menu_position,
				'menu_icon'             => 'dashicons-info',
				'supports'              => array('title', 'editor', 'thumbnail', ),
			);

			$args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

			register_post_type( self::$post_type, $args );
	                flush_rewrite_rules();
			/* post type end */		
		}	
	}
endif;


/*lector custompost for Case Study */
if ( !class_exists('Case_Study_Custom_Post_Type') ):
	class Case_Study_Custom_Post_Type {
		public static $post_type = 'case-study';
		public static $menu_position = 11;
		public static function register() {
			
			
			$labels = array(
				'name'                  => esc_html__('Case Studies',                 'lector'),
				'singular_name'         => esc_html__('Case Study',            	  'lector'),
				'add_new'               => esc_html__('Add New Case Study',          'lector'),
				'add_new_item'          => esc_html__('Add New Case Study',          'lector'),
				'edit_item'             => esc_html__('Edit Case Study',             'lector'),
				'new_item'              => esc_html__('New Case Study',              'lector'),
				'view_item'             => esc_html__('View Case Study',             'lector'),
				'search_items'          => esc_html__('Search Case Study',           'lector'),
				'not_found'             => esc_html__('No Case Study found',         'lector'),
				'not_found_in_trash'    => esc_html__('No Case Study found in trash','lector'),
				'all_items'			    => esc_html__( 'All Case Study', 			  'lector' ), 
				'featured_image'        => esc_html__( 'Case Study image', 		  'lector' ),    
			    'set_featured_image'    => esc_html__( 'Set Case Study image', 	  'lector' ),    
			    'remove_featured_image' => esc_html__( 'Remove Case Study image', 	  'lector' ), 
			    'use_featured_image'    => esc_html__( 'Use as Case Study image',    'lector' ),
				'parent_item_colon'     => '',
				'menu_name'             => esc_html__('Case Studies',                 'lector')
			);

		
			$args = array(
				'labels'                => $labels,
				'public'                => true,
				'publicly_queryable'    => true,
				'show_ui'               => true,
				'show_in_menu'          => true, 
				'query_var'             => true,
				'rewrite'               => array( 'slug' => self::$post_type ),
				'capability_type'       => 'post',
				'has_archive'           => false, 
				'hierarchical'          => false,
				'menu_position'         => self::$menu_position,
				'menu_icon'             => 'dashicons-star-filled',
				'supports'              => array('title','editor', 'thumbnail'),
			);

			$args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

			register_post_type( self::$post_type, $args );
	                flush_rewrite_rules();
					
		}	
	}
endif;

/*lector Case Study taxonomy*/
if ( !class_exists('case_study_custom_post_taxonomy') ):
	function case_study_custom_post_taxonomy() {
	    register_taxonomy(
	        'case', 
	        'case-study',               
	        array(
	            'label'                 => 'Case Studys Category',
	            'show_admin_column'     => true,
	            'hierarchical'    => true,
	        )
	    );
	}
	add_action( 'init', 'case_study_custom_post_taxonomy');
 
endif;
/*lector Case Study taxonomy*/


/////////////////////////
// Register post types //
/////////////////////////

if ( ! function_exists( 'lector_register_post_types' ) ) :
	function lector_register_post_types() {
		Lector_Service_Custom_Post_Type::register();
		Case_Study_Custom_Post_Type::register();
}
add_action( 'init', 'lector_register_post_types', 10 );
endif;