<?php
/*
This is displaying Social share
*/
defined( 'ABSPATH' ) || exit;
 
if( ! function_exists('lector_social_share')){
	function lector_social_share(){
	    
	?>
	<li>
		<a onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo site_url();?>','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.facebook.com/sharer.php?u=<?php echo site_url();?>">
			<i class="fab fa-facebook-f"></i>
        </a>
    </li>
    <li>
		<a onClick="window.open('http://www.instagram.com/sharer.php?u=<?php echo site_url();?>','Instagram','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.instagram.com/sharer.php?u=<?php echo site_url();?>">
            <i class="fab fa-instagram"></i>
        </a>
    </li>
    <li>
		<a onClick="window.open('http://twitter.com/share?url=<?php echo site_url();?>&amp;text=<?php bloginfo('title'); ?>','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://twitter.com/share?url=<?php echo site_url();?>&amp;text=<?php echo str_replace(" ", "%20", bloginfo('title')); ?>">
            <i class="fab fa-twitter"></i>
        </a> 
    </li>
    <li>	

		<a href="https://www.linkedin.com/share?url=<?php echo site_url(); ?>" onclick="window.open( 'https://www.linkedin.com/share?url=<?php echo site_url(); ?>', 'sharer', 'toolbar=0, status=0, width=600, height=300'); return false;">
            <i class="fab fa-linkedin-in"></i>
		</a>
    </li>
    <?php
    
	}
}



/*Social share for blog single page bottom*/ 
if( ! function_exists('lector_social_share_blog_single')){
	function lector_social_share_blog_single(){
	    
	?>
	<li>
		<a onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo site_url();?>','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" class="facebook" href="http://www.facebook.com/sharer.php?u=<?php echo site_url();?>">
			<i class="fab fa-facebook-f"></i>
        </a>
    </li>
    <li>
		<a onClick="window.open('http://www.instagram.com/sharer.php?u=<?php echo site_url();?>','Instagram','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" class="youtube" href="http://www.instagram.com/sharer.php?u=<?php echo site_url();?>">
            <i class="fab fa-instagram"></i>
        </a>
    </li>
    <li>
		<a onClick="window.open('http://twitter.com/share?url=<?php echo site_url();?>&amp;text=<?php bloginfo('title'); ?>','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" class="twitter" href="http://twitter.com/share?url=<?php echo site_url();?>&amp;text=<?php echo str_replace(" ", "%20", bloginfo('title')); ?>">
            <i class="fab fa-twitter"></i>
        </a> 
    </li>
    <li>	

		<a class="linkedin" href="https://www.linkedin.com/share?url=<?php echo site_url(); ?>" onclick="window.open( 'https://www.linkedin.com/share?url=<?php echo site_url(); ?>', 'sharer', 'toolbar=0, status=0, width=600, height=300'); return false;">
            <i class="fab fa-linkedin-in"></i>
		</a>
    </li>
    <?php
    
	}
}