<?php
/**
 * Plugin Name: Lector Companion
 * Plugin URI: https://themeforest.net/user/codexcoder
 * Description: This plugin is essential for lector theme
 * Author: CodexCoder
 * Author URI: http://codexcoder.com/
 * Version: 1.0.0
 * Text Domain: lector
 */
defined( 'ABSPATH' ) || exit;

/**
* Define Plugin DIR
*/
define( 'LECTOR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );


/*
* All Custom Post types on this file
*/
require_once( LECTOR_PLUGIN_DIR . 'lector-custompost.php' ); 

/*
* The Social Share only for Blog single posts
*/
require_once( LECTOR_PLUGIN_DIR . 'lector-social-share.php' );


/*Theme widgets*/
require_once LECTOR_PLUGIN_DIR . '/widgets/footer-circle-widget/footer-circle-widget-class.php';
require_once LECTOR_PLUGIN_DIR . '/widgets/footer-right-address/footer-right-address-widget-class.php';

/*Blog widgets*/
require_once LECTOR_PLUGIN_DIR . '/widgets/search-widget/search-widget.php';

/** search page widget **/
require_once LECTOR_PLUGIN_DIR . '/widgets/search-page-widget/search-widget.php';

require_once LECTOR_PLUGIN_DIR . '/widgets/category/class-category-widget.php';
require_once LECTOR_PLUGIN_DIR . '/widgets/latest-posts/class-widget-latest-news.php';
require_once LECTOR_PLUGIN_DIR . '/widgets/tags-clouds/tag-cloud-class-widget.php';
